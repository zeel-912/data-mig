from pathlib import Path
from pydantic import field_validator, computed_field
from pydantic_settings import BaseSettings, SettingsConfigDict


class XrayConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="XRAY_")

    client_id: str = ""
    client_secret: str = ""
    region: str = "eu"

    @computed_field
    @property
    def graphql_url(self) -> str:
        return f"https://{self.region}.xray.cloud.getxray.app/api/v2/graphql"

    @computed_field
    @property
    def auth_url(self) -> str:
        return "https://xray.cloud.getxray.app/api/v2/authenticate"


class JiraConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="JIRA_")

    domain: str = ""
    email: str = ""
    api_token: str = ""

    @computed_field
    @property
    def base_url(self) -> str:
        return f"https://{self.domain}/rest/api/3"


class DatabaseConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SQLITE_")

    db_path: str = "./data/migration.db"


class WaveConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="WAVE_")

    concurrency: int = 40
    resolvers_per_call: int = 12
    retry_resolvers_per_call: int = 4
    max_retries_per_wave: int = 2
    max_xray_resolvers: int = 25
    save_payloads: bool = False

    @field_validator("resolvers_per_call")
    @classmethod
    def validate_resolvers(cls, v: int) -> int:
        if v > 25:
            raise ValueError(
                f"resolvers_per_call={v} exceeds Xray max of 25 resolvers per GraphQL call"
            )
        if v < 1:
            raise ValueError("resolvers_per_call must be at least 1")
        return v

    @field_validator("retry_resolvers_per_call")
    @classmethod
    def validate_retry_resolvers(cls, v: int) -> int:
        if v > 25:
            raise ValueError(
                f"retry_resolvers_per_call={v} exceeds Xray max of 25"
            )
        if v < 1:
            raise ValueError("retry_resolvers_per_call must be at least 1")
        return v

    @computed_field
    @property
    def records_per_wave(self) -> int:
        return self.concurrency * self.resolvers_per_call

    @computed_field
    @property
    def retry_records_per_wave(self) -> int:
        return self.concurrency * self.retry_resolvers_per_call


class LogConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="LOG_")

    level: str = "INFO"
    dir: str = "./logs"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    xray: XrayConfig = XrayConfig()
    jira: JiraConfig = JiraConfig()
    database: DatabaseConfig = DatabaseConfig()
    wave: WaveConfig = WaveConfig()
    log: LogConfig = LogConfig()

    def ensure_directories(self) -> None:
        Path(self.database.db_path).parent.mkdir(parents=True, exist_ok=True)
        Path(self.log.dir).mkdir(parents=True, exist_ok=True)
