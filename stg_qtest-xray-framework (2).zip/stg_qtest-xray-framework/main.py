import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config.settings import Settings
from config.operations import (
    OperationName,
    PipelineName,
    ExecutionMode,
    OPERATION_SEQUENCE,
)
from db.connection import get_connection
from db.migrations import run_migrations
from common.logger import setup_logging, get_logger
from loguru import logger

import operations  # noqa: F401 — triggers operation registration


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="qTest to Xray Migration Framework — Staging to Xray/Jira",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--pipeline",
        type=str,
        choices=[p.value for p in PipelineName],
        default=PipelineName.STG_TO_XRAY.value,
        help="Pipeline name (default: STG_TO_XRAY)",
    )
    parser.add_argument(
        "--mode",
        type=str,
        choices=[m.value for m in ExecutionMode],
        required=True,
        help="Execution mode: FULL, OPERATION_ONLY, SPECIFIC_IDS, FAILED_RECORDS",
    )
    parser.add_argument(
        "--operation",
        type=str,
        choices=[op.value for op in OperationName],
        default=None,
        help="Operation to run (required for OPERATION_ONLY, SPECIFIC_IDS, FAILED_RECORDS)",
    )
    parser.add_argument(
        "--application",
        type=str,
        required=True,
        help="Application name (e.g., FH360)",
    )
    parser.add_argument(
        "--root-module-id",
        type=int,
        required=True,
        help="Root input module ID from staging",
    )
    parser.add_argument(
        "--scope",
        type=str,
        default="MIGRATION",
        help="Migration scope (default: MIGRATION)",
    )
    parser.add_argument(
        "--target-project-key",
        type=str,
        required=True,
        help="Target Jira/Xray project key (e.g., MT)",
    )
    parser.add_argument(
        "--target-project-id",
        type=str,
        default=None,
        help="Target Jira project ID (optional)",
    )
    parser.add_argument(
        "--source-ids",
        type=str,
        default=None,
        help="Comma-separated source IDs for SPECIFIC_IDS mode",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate configuration and show plan without executing",
    )
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    mode = ExecutionMode(args.mode)

    if mode in (
        ExecutionMode.OPERATION_ONLY,
        ExecutionMode.SPECIFIC_IDS,
        ExecutionMode.FAILED_RECORDS,
    ):
        if not args.operation:
            logger.error(
                f"--operation is required for mode={mode.value}"
            )
            sys.exit(1)

    if mode == ExecutionMode.SPECIFIC_IDS:
        if not args.source_ids:
            logger.error(
                "--source-ids is required for mode=SPECIFIC_IDS"
            )
            sys.exit(1)


def main() -> None:
    args = parse_args()

    settings = Settings()
    settings.ensure_directories()

    setup_logging(
        log_level=settings.log.level,
        log_dir=settings.log.dir,
    )

    validate_args(args)

    logger.info("Initializing database...")
    conn = get_connection(settings.database.db_path)
    run_migrations(conn)
    logger.info(f"Database ready at: {settings.database.db_path}")

    logger.info("=" * 60)
    logger.info("qTest → Xray Migration Framework")
    logger.info("=" * 60)
    logger.info(f"Pipeline:       {args.pipeline}")
    logger.info(f"Mode:           {args.mode}")
    logger.info(f"Application:    {args.application}")
    logger.info(f"Root Module ID: {args.root_module_id}")
    logger.info(f"Scope:          {args.scope}")
    logger.info(f"Target Project: {args.target_project_key}")
    logger.info(f"Dry Run:        {args.dry_run}")
    logger.info(f"Wave Config:    {settings.wave.concurrency} calls × {settings.wave.resolvers_per_call} resolvers = {settings.wave.records_per_wave} records/wave")
    logger.info(f"Retry Config:   {settings.wave.retry_resolvers_per_call} resolvers/call, max {settings.wave.max_retries_per_wave} retry rounds")
    logger.info("=" * 60)

    if args.mode == ExecutionMode.FULL.value:
        logger.info(f"Operation sequence ({len(OPERATION_SEQUENCE)} operations):")
        for i, op in enumerate(OPERATION_SEQUENCE, 1):
            logger.info(f"  {i:2d}. {op.value}")

    if args.dry_run:
        logger.info("DRY RUN complete. No operations executed.")
        conn.close()
        return

    asyncio.run(_run_pipeline(conn, settings, args))
    conn.close()


async def _run_pipeline(conn, settings: Settings, args: argparse.Namespace) -> None:
    """Initialize clients and run the pipeline."""
    from clients.xray_graphql_client import XrayGraphQLClient
    from clients.jira_rest_client import JiraRestClient
    from common.rate_limiter import RateLimiter
    from operations.pipeline_runner import PipelineRunner
    from operations.base import PipelineContext
    from db.repositories.pipeline_repo import PipelineRepo

    xray_rate_limiter = RateLimiter(requests_per_second=50.0, burst_size=50)
    jira_rate_limiter = RateLimiter(requests_per_second=10.0, burst_size=10)

    xray_client = XrayGraphQLClient(
        client_id=settings.xray.client_id,
        client_secret=settings.xray.client_secret,
        region=settings.xray.region,
        graphql_url=settings.xray.graphql_url,
        auth_url=settings.xray.auth_url,
        rate_limiter=xray_rate_limiter,
    )

    jira_client = JiraRestClient(
        domain=settings.jira.domain,
        email=settings.jira.email,
        api_token=settings.jira.api_token,
        base_url=settings.jira.base_url,
        rate_limiter=jira_rate_limiter,
    )

    await xray_client.initialize()

    try:
        pipeline_repo = PipelineRepo(conn)
        pipeline_run_id = pipeline_repo.create_pipeline_run(
            pipeline_name=args.pipeline,
            application_name=args.application,
            root_input_module_id=args.root_module_id,
            target_project_key=args.target_project_key,
            migration_scope=args.scope,
            target_project_id=args.target_project_id,
            config_snapshot=f"concurrency={settings.wave.concurrency},resolvers={settings.wave.resolvers_per_call}",
        )

        context = PipelineContext(
            pipeline_run_id=pipeline_run_id,
            application_name=args.application,
            root_input_module_id=args.root_module_id,
            target_project_key=args.target_project_key,
            target_project_id=args.target_project_id,
            migration_scope=args.scope,
            mode=ExecutionMode(args.mode),
            source_ids=args.source_ids.split(",") if args.source_ids else None,
        )

        runner = PipelineRunner(
            conn=conn,
            settings=settings,
            xray_client=xray_client,
            jira_client=jira_client,
        )

        mode = ExecutionMode(args.mode)
        if mode == ExecutionMode.FULL:
            await runner.run_full_pipeline(context)
        elif mode == ExecutionMode.OPERATION_ONLY:
            await runner.run_single_operation(context, OperationName(args.operation))
        elif mode == ExecutionMode.FAILED_RECORDS:
            await runner.run_failed_records(context, OperationName(args.operation))
        elif mode == ExecutionMode.SPECIFIC_IDS:
            context.source_ids = args.source_ids.split(",") if args.source_ids else []
            await runner.run_single_operation(context, OperationName(args.operation))

    finally:
        await xray_client.close()


if __name__ == "__main__":
    main()
