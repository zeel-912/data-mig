import asyncio
import time
import base64
from loguru import logger
import httpx


class XrayAuthManager:
    """Manages Xray Cloud JWT token lifecycle.

    Token TTL is ~60 minutes. Refreshes proactively at 55 minutes
    to avoid mid-request expiration during long migrations.
    """

    TOKEN_REFRESH_SECONDS = 55 * 60

    def __init__(self, client_id: str, client_secret: str, auth_url: str):
        self._client_id = client_id
        self._client_secret = client_secret
        self._auth_url = auth_url
        self._token: str | None = None
        self._token_acquired_at: float = 0.0
        self._lock = asyncio.Lock()

    async def get_token(self, http_client: httpx.AsyncClient) -> str:
        async with self._lock:
            if self._is_token_valid():
                return self._token

            self._token = await self._authenticate(http_client)
            self._token_acquired_at = time.monotonic()
            return self._token

    def _is_token_valid(self) -> bool:
        if not self._token:
            return False
        elapsed = time.monotonic() - self._token_acquired_at
        return elapsed < self.TOKEN_REFRESH_SECONDS

    async def _authenticate(self, http_client: httpx.AsyncClient) -> str:
        logger.info("Xray auth: acquiring new JWT token")
        response = await http_client.post(
            self._auth_url,
            json={
                "client_id": self._client_id,
                "client_secret": self._client_secret,
            },
            timeout=30.0,
        )

        if response.status_code != 200:
            raise RuntimeError(
                f"Xray authentication failed: {response.status_code} {response.text}"
            )

        token = response.text.strip('"')
        logger.info("Xray auth: token acquired successfully")
        return token

    def invalidate(self) -> None:
        self._token = None
        self._token_acquired_at = 0.0


class JiraAuthManager:
    """Constructs Jira Cloud Basic Auth header from email + API token."""

    def __init__(self, email: str, api_token: str):
        credentials = f"{email}:{api_token}"
        encoded = base64.b64encode(credentials.encode()).decode()
        self._auth_header = f"Basic {encoded}"

    @property
    def auth_header(self) -> str:
        return self._auth_header

    def get_headers(self) -> dict[str, str]:
        return {
            "Authorization": self._auth_header,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
