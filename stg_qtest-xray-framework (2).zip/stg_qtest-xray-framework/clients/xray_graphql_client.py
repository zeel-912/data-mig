import time
import httpx
from loguru import logger

from clients.auth import XrayAuthManager
from common.rate_limiter import RateLimiter
from common.exceptions import (
    RateLimitError,
    SystemLevelError,
    GraphQLPartialError,
)
from common.models import (
    SourceRecord,
    ApiCall,
    CallResult,
    CallStatus,
    RecordResult,
)
from common.retry import retry_with_backoff


class XrayGraphQLClient:
    """Xray Cloud GraphQL API client with aliased mutation batching.

    Handles:
    - JWT token lifecycle (auto-refresh at 55 min)
    - Aliased mutation building (N records per single GraphQL call)
    - Per-alias response parsing (separates successes from failures)
    - Rate limiting integration
    - 429 / 5xx error handling
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        region: str,
        graphql_url: str,
        auth_url: str,
        rate_limiter: RateLimiter,
    ):
        self._graphql_url = graphql_url
        self._rate_limiter = rate_limiter
        self._auth_manager = XrayAuthManager(client_id, client_secret, auth_url)
        self._http_client: httpx.AsyncClient | None = None

    async def initialize(self) -> None:
        self._http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(60.0, connect=10.0),
            limits=httpx.Limits(
                max_connections=100,
                max_keepalive_connections=50,
            ),
        )

    async def close(self) -> None:
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    async def _get_headers(self) -> dict[str, str]:
        token = await self._auth_manager.get_token(self._http_client)
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    async def execute(self, query: str, variables: dict | None = None) -> dict:
        """Execute a raw GraphQL query/mutation. Returns parsed JSON response."""
        await self._rate_limiter.acquire()

        headers = await self._get_headers()
        payload = {"query": query}
        if variables:
            payload["variables"] = variables

        response = await self._http_client.post(
            self._graphql_url,
            json=payload,
            headers=headers,
        )

        self._rate_limiter.notify_response(
            response.status_code,
            dict(response.headers),
        )

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "5")
            raise RateLimitError(
                f"Xray GraphQL rate limited: {response.status_code}",
                retry_after_seconds=float(retry_after),
            )

        if response.status_code >= 500:
            raise SystemLevelError(
                f"Xray GraphQL server error: {response.status_code} {response.text}",
                status_code=response.status_code,
            )

        if response.status_code != 200:
            raise SystemLevelError(
                f"Xray GraphQL error: {response.status_code} {response.text}",
                status_code=response.status_code,
            )

        return response.json()

    def build_aliased_mutation(
        self,
        mutation_template: str,
        records: list[dict],
        alias_prefix: str = "op",
        return_fields: str = "{ issueId }",
    ) -> str:
        """Build a single GraphQL mutation with N aliases from a template.

        Args:
            mutation_template: GraphQL mutation body with {args} placeholder.
                Example: 'createTest(testType: {test_type}, jira: {jira})'
            records: List of dicts, each containing the arguments for one alias.
            alias_prefix: Prefix for alias names (op_0, op_1, ...).
            return_fields: GraphQL return fields block.

        Returns:
            Complete GraphQL mutation string ready for execute().

        Example output:
            mutation {
              op_0: createFolder(projectId: "10001", path: "/Regression") { folder { path } }
              op_1: createFolder(projectId: "10001", path: "/Smoke") { folder { path } }
            }
        """
        aliases = []
        for i, record in enumerate(records):
            alias_name = f"{alias_prefix}_{i}"
            args_str = self._build_args_string(record)
            aliases.append(f"  {alias_name}: {mutation_template}({args_str}) {return_fields}")

        mutation = "mutation {\n" + "\n".join(aliases) + "\n}"
        return mutation

    def _build_args_string(self, args: dict) -> str:
        """Convert a dict of arguments to a GraphQL arguments string."""
        parts = []
        for key, value in args.items():
            parts.append(f"{key}: {self._format_value(value)}")
        return ", ".join(parts)

    def _format_value(self, value) -> str:
        """Format a Python value as a GraphQL literal."""
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, str):
            escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
            return f'"{escaped}"'
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, list):
            items = ", ".join(self._format_value(v) for v in value)
            return f"[{items}]"
        if isinstance(value, dict):
            parts = []
            for k, v in value.items():
                parts.append(f"{k}: {self._format_value(v)}")
            return "{" + ", ".join(parts) + "}"
        return f'"{value}"'

    def parse_aliased_response(
        self,
        response_data: dict,
        records: list[SourceRecord],
        alias_prefix: str = "op",
        target_id_field: str = "issueId",
        target_key_field: str | None = None,
        target_path_field: str | None = None,
    ) -> tuple[list[RecordResult], list[RecordResult]]:
        """Parse a GraphQL response with aliases back to per-record results.

        Separates successful aliases from failed ones (null data or errors).

        Returns:
            (successes, failures) - lists of RecordResult
        """
        data = response_data.get("data", {}) or {}
        errors = response_data.get("errors", []) or []

        error_map: dict[str, str] = {}
        for error in errors:
            path = error.get("path", [])
            if path:
                error_map[path[0]] = error.get("message", "Unknown error")

        successes: list[RecordResult] = []
        failures: list[RecordResult] = []

        for i, record in enumerate(records):
            alias_name = f"{alias_prefix}_{i}"
            alias_data = data.get(alias_name)

            if alias_name in error_map:
                failures.append(RecordResult(
                    source_record=record,
                    success=False,
                    error_code="GRAPHQL_ERROR",
                    error_message=error_map[alias_name],
                ))
            elif alias_data is None:
                failures.append(RecordResult(
                    source_record=record,
                    success=False,
                    error_code="NULL_RESPONSE",
                    error_message=f"Alias {alias_name} returned null",
                ))
            else:
                target_id = None
                target_key = None
                target_path = None

                if target_id_field and isinstance(alias_data, dict):
                    target_id = alias_data.get(target_id_field)
                if target_key_field and isinstance(alias_data, dict):
                    jira_data = alias_data.get("jira", {})
                    if isinstance(jira_data, dict):
                        target_key = jira_data.get(target_key_field)
                    else:
                        target_key = alias_data.get(target_key_field)
                if target_path_field and isinstance(alias_data, dict):
                    nested = alias_data.get("folder", alias_data)
                    if isinstance(nested, dict):
                        target_path = nested.get(target_path_field)

                successes.append(RecordResult(
                    source_record=record,
                    success=True,
                    target_id=str(target_id) if target_id else None,
                    target_key=target_key,
                    target_path=target_path,
                    raw_response=alias_data,
                ))

        return successes, failures

    async def execute_api_call(
        self,
        call: ApiCall,
        mutation_template: str,
        record_to_args_fn,
        alias_prefix: str = "op",
        return_fields: str = "{ issueId }",
        target_id_field: str = "issueId",
        target_key_field: str | None = None,
        target_path_field: str | None = None,
    ) -> CallResult:
        """Execute a single API call (batch of records as aliased mutations).

        This is the function passed to WaveExecutor.execute_all_waves() as api_fn.
        """
        start = time.monotonic()

        try:
            args_list = [record_to_args_fn(r) for r in call.records]
            query = self.build_aliased_mutation(
                mutation_template, args_list, alias_prefix, return_fields
            )

            response_data = await retry_with_backoff(
                self.execute,
                query,
                max_attempts=3,
                base_delay=2.0,
            )

            successes, failures = self.parse_aliased_response(
                response_data,
                call.records,
                alias_prefix,
                target_id_field,
                target_key_field,
                target_path_field,
            )

            duration_ms = (time.monotonic() - start) * 1000

            if failures and not successes:
                status = CallStatus.FAILED
            elif failures:
                status = CallStatus.PARTIAL_SUCCESS
            else:
                status = CallStatus.SUCCESS

            return CallResult(
                call_id=call.call_id,
                status=status,
                successes=successes,
                failures=failures,
                raw_request=query,
                raw_response=response_data,
                duration_ms=duration_ms,
            )

        except RateLimitError as e:
            duration_ms = (time.monotonic() - start) * 1000
            failures = [
                RecordResult(
                    source_record=r,
                    success=False,
                    error_code="RATE_LIMITED",
                    error_message=str(e),
                )
                for r in call.records
            ]
            return CallResult(
                call_id=call.call_id,
                status=CallStatus.RATE_LIMITED,
                failures=failures,
                duration_ms=duration_ms,
                retry_after_seconds=e.retry_after_seconds,
            )

        except Exception as e:
            duration_ms = (time.monotonic() - start) * 1000
            logger.error(f"Call {call.call_id} failed with exception: {e}")
            failures = [
                RecordResult(
                    source_record=r,
                    success=False,
                    error_code="SYSTEM_ERROR",
                    error_message=str(e),
                )
                for r in call.records
            ]
            return CallResult(
                call_id=call.call_id,
                status=CallStatus.FAILED,
                failures=failures,
                duration_ms=duration_ms,
            )
