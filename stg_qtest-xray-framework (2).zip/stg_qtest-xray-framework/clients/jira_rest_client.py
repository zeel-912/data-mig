import time
import httpx
from loguru import logger

from clients.auth import JiraAuthManager
from common.rate_limiter import RateLimiter
from common.exceptions import RateLimitError, SystemLevelError
from common.retry import retry_with_backoff


class JiraRestClient:
    """Jira Cloud REST API v3 client.

    Handles:
    - Basic Auth authentication
    - Rate limiting with Retry-After respect
    - 429 / 5xx error handling with retry
    - Issue CRUD, transitions, attachments, comments
    """

    def __init__(
        self,
        domain: str,
        email: str,
        api_token: str,
        base_url: str,
        rate_limiter: RateLimiter,
    ):
        self._base_url = base_url
        self._rate_limiter = rate_limiter
        self._auth_manager = JiraAuthManager(email, api_token)
        self._http_client: httpx.AsyncClient | None = None

    async def initialize(self) -> None:
        self._http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(60.0, connect=10.0),
            limits=httpx.Limits(
                max_connections=100,
                max_keepalive_connections=50,
            ),
            headers=self._auth_manager.get_headers(),
        )

    async def close(self) -> None:
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    async def _request(
        self,
        method: str,
        path: str,
        json: dict | None = None,
        params: dict | None = None,
        headers: dict | None = None,
    ) -> dict:
        await self._rate_limiter.acquire()

        url = f"{self._base_url}{path}"
        response = await self._http_client.request(
            method,
            url,
            json=json,
            params=params,
            headers=headers,
        )

        self._rate_limiter.notify_response(
            response.status_code,
            dict(response.headers),
        )

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "5")
            raise RateLimitError(
                f"Jira rate limited: {response.status_code}",
                retry_after_seconds=float(retry_after),
            )

        if response.status_code >= 500:
            raise SystemLevelError(
                f"Jira server error: {response.status_code} {response.text}",
                status_code=response.status_code,
            )

        if response.status_code == 204:
            return {}

        if response.status_code >= 400:
            raise SystemLevelError(
                f"Jira client error: {response.status_code} {response.text}",
                status_code=response.status_code,
            )

        if not response.text:
            return {}

        return response.json()

    async def get(self, path: str, params: dict | None = None) -> dict:
        return await retry_with_backoff(
            self._request, "GET", path, params=params, max_attempts=3
        )

    async def post(self, path: str, json: dict | None = None) -> dict:
        return await retry_with_backoff(
            self._request, "POST", path, json=json, max_attempts=3
        )

    async def put(self, path: str, json: dict | None = None) -> dict:
        return await retry_with_backoff(
            self._request, "PUT", path, json=json, max_attempts=3
        )

    async def delete(self, path: str) -> dict:
        return await retry_with_backoff(
            self._request, "DELETE", path, max_attempts=3
        )

    async def create_issue(
        self,
        project_key: str,
        issue_type: str,
        summary: str,
        fields: dict | None = None,
    ) -> dict:
        payload = {
            "fields": {
                "project": {"key": project_key},
                "issuetype": {"name": issue_type},
                "summary": summary,
                **(fields or {}),
            }
        }
        return await self.post("/issue", json=payload)

    async def update_issue(self, issue_key: str, fields: dict) -> dict:
        payload = {"fields": fields}
        return await self.put(f"/issue/{issue_key}", json=payload)

    async def get_issue(
        self, issue_key: str, expand: str | None = None
    ) -> dict:
        params = {}
        if expand:
            params["expand"] = expand
        return await self.get(f"/issue/{issue_key}", params=params or None)

    async def get_transitions(self, issue_key: str) -> dict:
        return await self.get(f"/issue/{issue_key}/transitions")

    async def transition_issue(
        self, issue_key: str, transition_id: str
    ) -> dict:
        payload = {"transition": {"id": transition_id}}
        return await self.post(f"/issue/{issue_key}/transitions", json=payload)

    async def bulk_transition(
        self, issue_keys: list[str], transition_id: str
    ) -> dict:
        """Bulk transition up to 1000 issues. Returns taskId for polling."""
        payload = {
            "issues": [{"key": k, "transition": {"id": transition_id}} for k in issue_keys],
            "sendBulkNotification": False,
        }
        return await self.post("/bulk/issues/transition", json=payload)

    async def poll_task(self, task_id: str) -> dict:
        return await self.get(f"/task/{task_id}")

    async def add_attachment(
        self, issue_key: str, file_path: str, filename: str
    ) -> dict:
        """Upload attachment to a Jira issue."""
        await self._rate_limiter.acquire()

        url = f"{self._base_url}/issue/{issue_key}/attachments"
        headers = {
            "X-Atlassian-Token": "no-check",
        }

        with open(file_path, "rb") as f:
            files = {"file": (filename, f)}
            response = await self._http_client.post(
                url,
                files=files,
                headers=headers,
            )

        self._rate_limiter.notify_response(
            response.status_code,
            dict(response.headers),
        )

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "5")
            raise RateLimitError(
                f"Jira attachment rate limited",
                retry_after_seconds=float(retry_after),
            )

        if response.status_code >= 400:
            raise SystemLevelError(
                f"Jira attachment error: {response.status_code} {response.text}",
                status_code=response.status_code,
            )

        return response.json()

    async def add_comment(self, issue_key: str, body: str) -> dict:
        """Add a comment with ADF body to a Jira issue."""
        payload = {
            "body": {
                "type": "doc",
                "version": 1,
                "content": [
                    {
                        "type": "paragraph",
                        "content": [
                            {"type": "text", "text": body}
                        ],
                    }
                ],
            }
        }
        return await self.post(f"/issue/{issue_key}/comment", json=payload)

    async def search_issues(self, jql: str, fields: list[str] | None = None, max_results: int = 50) -> dict:
        payload = {
            "jql": jql,
            "maxResults": max_results,
        }
        if fields:
            payload["fields"] = fields
        return await self.post("/search", json=payload)
