import sqlite3
from datetime import datetime, timezone


class MappingRepo:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def save_mapping(
        self,
        pipeline_run_id: int,
        operation_run_id: int,
        source_entity_type: str,
        source_id: str,
        target_entity_type: str,
        target_id: str | None = None,
        target_key: str | None = None,
        target_path: str | None = None,
        relationship_context: str | None = None,
    ) -> int:
        now = datetime.now(timezone.utc).isoformat()
        cursor = self.conn.execute(
            """
            INSERT OR REPLACE INTO id_mapping (
                pipeline_run_id, operation_run_id, source_entity_type,
                source_id, target_entity_type, target_id, target_key,
                target_path, relationship_context, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                pipeline_run_id,
                operation_run_id,
                source_entity_type,
                source_id,
                target_entity_type,
                target_id,
                target_key,
                target_path,
                relationship_context,
                now,
                now,
            ),
        )
        self.conn.commit()
        return cursor.lastrowid

    def save_mappings_bulk(self, mappings: list[dict]) -> int:
        if not mappings:
            return 0

        now = datetime.now(timezone.utc).isoformat()
        rows = [
            (
                m["pipeline_run_id"],
                m["operation_run_id"],
                m["source_entity_type"],
                m["source_id"],
                m["target_entity_type"],
                m.get("target_id"),
                m.get("target_key"),
                m.get("target_path"),
                m.get("relationship_context"),
                now,
                now,
            )
            for m in mappings
        ]
        self.conn.executemany(
            """
            INSERT OR REPLACE INTO id_mapping (
                pipeline_run_id, operation_run_id, source_entity_type,
                source_id, target_entity_type, target_id, target_key,
                target_path, relationship_context, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        self.conn.commit()
        return len(rows)

    def get_mapping(
        self, source_entity_type: str, source_id: str
    ) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM id_mapping
            WHERE source_entity_type = ? AND source_id = ?
            """,
            (source_entity_type, source_id),
        ).fetchone()

    def mapping_exists(self, source_entity_type: str, source_id: str) -> bool:
        row = self.conn.execute(
            """
            SELECT 1 FROM id_mapping
            WHERE source_entity_type = ? AND source_id = ?
            LIMIT 1
            """,
            (source_entity_type, source_id),
        ).fetchone()
        return row is not None

    def get_mappings_for_operation(self, operation_run_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM id_mapping WHERE operation_run_id = ?",
            (operation_run_id,),
        ).fetchall()

    def get_mappings_by_entity_type(
        self, source_entity_type: str
    ) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM id_mapping WHERE source_entity_type = ?",
            (source_entity_type,),
        ).fetchall()

    def get_mapped_count_for_operation(self, operation_run_id: int) -> int:
        row = self.conn.execute(
            "SELECT COUNT(*) as cnt FROM id_mapping WHERE operation_run_id = ?",
            (operation_run_id,),
        ).fetchone()
        return row["cnt"] if row else 0
