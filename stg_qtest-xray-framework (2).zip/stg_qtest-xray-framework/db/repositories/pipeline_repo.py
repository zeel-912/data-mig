import sqlite3
from datetime import datetime, timezone


class PipelineRepo:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def create_pipeline_run(
        self,
        pipeline_name: str,
        application_name: str,
        root_input_module_id: int,
        target_project_key: str,
        migration_scope: str = "MIGRATION",
        source_project_id: int | None = None,
        target_project_id: str | None = None,
        triggered_by: str | None = None,
        config_snapshot: str | None = None,
    ) -> int:
        now = datetime.now(timezone.utc).isoformat()
        cursor = self.conn.execute(
            """
            INSERT INTO pipeline_run (
                pipeline_name, application_name, root_input_module_id,
                migration_scope, source_project_id, target_project_key,
                target_project_id, triggered_by, status, config_snapshot,
                started_at, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'RUNNING', ?, ?, ?, ?)
            """,
            (
                pipeline_name,
                application_name,
                root_input_module_id,
                migration_scope,
                source_project_id,
                target_project_key,
                target_project_id,
                triggered_by,
                config_snapshot,
                now,
                now,
                now,
            ),
        )
        self.conn.commit()
        return cursor.lastrowid

    def update_status(self, pipeline_run_id: int, status: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        completed_at = now if status in ("COMPLETED", "FAILED") else None
        self.conn.execute(
            """
            UPDATE pipeline_run
            SET status = ?, completed_at = COALESCE(?, completed_at), updated_at = ?
            WHERE pipeline_run_id = ?
            """,
            (status, completed_at, now, pipeline_run_id),
        )
        self.conn.commit()

    def get_pipeline_run(self, pipeline_run_id: int) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM pipeline_run WHERE pipeline_run_id = ?",
            (pipeline_run_id,),
        ).fetchone()

    def get_latest_for_application(
        self, application_name: str, pipeline_name: str
    ) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM pipeline_run
            WHERE application_name = ? AND pipeline_name = ?
            ORDER BY pipeline_run_id DESC LIMIT 1
            """,
            (application_name, pipeline_name),
        ).fetchone()
