import sqlite3
from datetime import datetime, timezone


class OperationRepo:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def create_operation_run(
        self,
        pipeline_run_id: int,
        operation_name: str,
        operation_sequence: int,
        operation_mode: str = "FULL",
    ) -> int:
        now = datetime.now(timezone.utc).isoformat()
        cursor = self.conn.execute(
            """
            INSERT INTO operation_run (
                pipeline_run_id, operation_name, operation_sequence,
                operation_status, operation_mode, started_at, created_at, updated_at
            ) VALUES (?, ?, ?, 'RUNNING', ?, ?, ?, ?)
            """,
            (
                pipeline_run_id,
                operation_name,
                operation_sequence,
                operation_mode,
                now,
                now,
                now,
            ),
        )
        self.conn.commit()
        return cursor.lastrowid

    def update_status(self, operation_run_id: int, status: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        completed_at = now if status in ("COMPLETED", "FAILED", "GATE_BLOCKED") else None
        self.conn.execute(
            """
            UPDATE operation_run
            SET operation_status = ?, completed_at = COALESCE(?, completed_at), updated_at = ?
            WHERE operation_run_id = ?
            """,
            (status, completed_at, now, operation_run_id),
        )
        self.conn.commit()

    def update_counts(
        self,
        operation_run_id: int,
        source_count: int = 0,
        eligible_count: int = 0,
        attempted_count: int = 0,
        success_count: int = 0,
        failure_count: int = 0,
        retry_count: int = 0,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            """
            UPDATE operation_run
            SET source_count = ?, eligible_count = ?, attempted_count = ?,
                success_count = ?, failure_count = ?, retry_count = ?, updated_at = ?
            WHERE operation_run_id = ?
            """,
            (
                source_count,
                eligible_count,
                attempted_count,
                success_count,
                failure_count,
                retry_count,
                now,
                operation_run_id,
            ),
        )
        self.conn.commit()

    def update_gate_status(self, operation_run_id: int, gate_status: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            """
            UPDATE operation_run
            SET dependency_gate_status = ?, updated_at = ?
            WHERE operation_run_id = ?
            """,
            (gate_status, now, operation_run_id),
        )
        self.conn.commit()

    def get_operation_run(self, operation_run_id: int) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM operation_run WHERE operation_run_id = ?",
            (operation_run_id,),
        ).fetchone()

    def get_operations_for_pipeline(self, pipeline_run_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM operation_run
            WHERE pipeline_run_id = ?
            ORDER BY operation_sequence
            """,
            (pipeline_run_id,),
        ).fetchall()

    def get_latest_for_operation(
        self, pipeline_run_id: int, operation_name: str
    ) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM operation_run
            WHERE pipeline_run_id = ? AND operation_name = ?
            ORDER BY operation_run_id DESC LIMIT 1
            """,
            (pipeline_run_id, operation_name),
        ).fetchone()
