import sqlite3
from datetime import datetime, timezone


class ReconciliationRepo:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def save_reconciliation(
        self,
        pipeline_run_id: int,
        operation_run_id: int,
        operation_name: str,
        source_count: int = 0,
        eligible_count: int = 0,
        attempted_count: int = 0,
        success_count: int = 0,
        failure_count: int = 0,
        mapped_count: int = 0,
        unresolved_count: int = 0,
        status: str | None = None,
        notes: str | None = None,
    ) -> int:
        now = datetime.now(timezone.utc).isoformat()
        cursor = self.conn.execute(
            """
            INSERT INTO reconciliation_summary (
                pipeline_run_id, operation_run_id, operation_name,
                source_count, eligible_count, attempted_count,
                success_count, failure_count, mapped_count,
                unresolved_count, status, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                pipeline_run_id,
                operation_run_id,
                operation_name,
                source_count,
                eligible_count,
                attempted_count,
                success_count,
                failure_count,
                mapped_count,
                unresolved_count,
                status,
                notes,
                now,
                now,
            ),
        )
        self.conn.commit()
        return cursor.lastrowid

    def get_for_operation(self, operation_run_id: int) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM reconciliation_summary
            WHERE operation_run_id = ?
            ORDER BY reconciliation_id DESC LIMIT 1
            """,
            (operation_run_id,),
        ).fetchone()

    def get_all_for_pipeline(self, pipeline_run_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM reconciliation_summary
            WHERE pipeline_run_id = ?
            ORDER BY operation_name
            """,
            (pipeline_run_id,),
        ).fetchall()
