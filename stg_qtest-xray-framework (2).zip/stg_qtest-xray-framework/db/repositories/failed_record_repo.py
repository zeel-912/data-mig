import sqlite3
from datetime import datetime, timezone


class FailedRecordRepo:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def save_failed_record(
        self,
        pipeline_run_id: int,
        operation_run_id: int,
        operation_name: str,
        source_entity_type: str,
        primary_source_id: str,
        operation_batch_id: int | None = None,
        related_source_ids_json: str | None = None,
        source_context_json: str | None = None,
        target_context_json: str | None = None,
        payload_snapshot_json: str | None = None,
        error_code: str | None = None,
        error_message: str | None = None,
        retry_count: int = 0,
    ) -> int:
        now = datetime.now(timezone.utc).isoformat()
        cursor = self.conn.execute(
            """
            INSERT INTO failed_record (
                pipeline_run_id, operation_run_id, operation_batch_id,
                operation_name, source_entity_type, primary_source_id,
                related_source_ids_json, source_context_json,
                target_context_json, payload_snapshot_json,
                error_code, error_message, retry_count,
                failure_status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'UNRESOLVED', ?, ?)
            """,
            (
                pipeline_run_id,
                operation_run_id,
                operation_batch_id,
                operation_name,
                source_entity_type,
                primary_source_id,
                related_source_ids_json,
                source_context_json,
                target_context_json,
                payload_snapshot_json,
                error_code,
                error_message,
                retry_count,
                now,
                now,
            ),
        )
        self.conn.commit()
        return cursor.lastrowid

    def save_failed_records_bulk(self, records: list[dict]) -> int:
        if not records:
            return 0

        now = datetime.now(timezone.utc).isoformat()
        rows = [
            (
                r["pipeline_run_id"],
                r["operation_run_id"],
                r.get("operation_batch_id"),
                r["operation_name"],
                r["source_entity_type"],
                r["primary_source_id"],
                r.get("related_source_ids_json"),
                r.get("source_context_json"),
                r.get("target_context_json"),
                r.get("payload_snapshot_json"),
                r.get("error_code"),
                r.get("error_message"),
                r.get("retry_count", 0),
                now,
                now,
            )
            for r in records
        ]
        self.conn.executemany(
            """
            INSERT INTO failed_record (
                pipeline_run_id, operation_run_id, operation_batch_id,
                operation_name, source_entity_type, primary_source_id,
                related_source_ids_json, source_context_json,
                target_context_json, payload_snapshot_json,
                error_code, error_message, retry_count,
                failure_status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'UNRESOLVED', ?, ?)
            """,
            rows,
        )
        self.conn.commit()
        return len(rows)

    def get_unresolved_for_operation(
        self, operation_run_id: int
    ) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM failed_record
            WHERE operation_run_id = ? AND failure_status = 'UNRESOLVED'
            ORDER BY failed_record_id
            """,
            (operation_run_id,),
        ).fetchall()

    def get_unresolved_count(self, operation_run_id: int) -> int:
        row = self.conn.execute(
            """
            SELECT COUNT(*) as cnt FROM failed_record
            WHERE operation_run_id = ? AND failure_status = 'UNRESOLVED'
            """,
            (operation_run_id,),
        ).fetchone()
        return row["cnt"] if row else 0

    def mark_resolved(
        self, failed_record_id: int, resolved_by: str = "AUTO_RETRY"
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            """
            UPDATE failed_record
            SET failure_status = 'RESOLVED', resolved_at = ?,
                resolved_by = ?, updated_at = ?
            WHERE failed_record_id = ?
            """,
            (now, resolved_by, now, failed_record_id),
        )
        self.conn.commit()

    def increment_retry_count(self, failed_record_id: int) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            """
            UPDATE failed_record
            SET retry_count = retry_count + 1, updated_at = ?
            WHERE failed_record_id = ?
            """,
            (now, failed_record_id),
        )
        self.conn.commit()
