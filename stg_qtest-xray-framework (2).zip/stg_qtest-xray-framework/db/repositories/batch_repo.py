import sqlite3
from datetime import datetime, timezone


class BatchRepo:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def create_batch(
        self,
        operation_run_id: int,
        pipeline_run_id: int,
        batch_number: int,
        wave_number: int | None = None,
        source_record_count: int = 0,
    ) -> int:
        now = datetime.now(timezone.utc).isoformat()
        cursor = self.conn.execute(
            """
            INSERT INTO operation_batch (
                operation_run_id, pipeline_run_id, batch_number,
                wave_number, batch_status, source_record_count,
                started_at, created_at, updated_at
            ) VALUES (?, ?, ?, ?, 'RUNNING', ?, ?, ?, ?)
            """,
            (
                operation_run_id,
                pipeline_run_id,
                batch_number,
                wave_number,
                source_record_count,
                now,
                now,
                now,
            ),
        )
        self.conn.commit()
        return cursor.lastrowid

    def update_status(self, batch_id: int, status: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        completed_at = now if status in ("COMPLETED", "FAILED") else None
        self.conn.execute(
            """
            UPDATE operation_batch
            SET batch_status = ?, completed_at = COALESCE(?, completed_at), updated_at = ?
            WHERE operation_batch_id = ?
            """,
            (status, completed_at, now, batch_id),
        )
        self.conn.commit()

    def update_counts(
        self,
        batch_id: int,
        attempted_count: int = 0,
        success_count: int = 0,
        failure_count: int = 0,
        retry_count: int = 0,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            """
            UPDATE operation_batch
            SET attempted_count = ?, success_count = ?,
                failure_count = ?, retry_count = ?, updated_at = ?
            WHERE operation_batch_id = ?
            """,
            (attempted_count, success_count, failure_count, retry_count, now, batch_id),
        )
        self.conn.commit()

    def get_batches_for_operation(self, operation_run_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM operation_batch
            WHERE operation_run_id = ?
            ORDER BY batch_number
            """,
            (operation_run_id,),
        ).fetchall()

    def get_batch(self, batch_id: int) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM operation_batch WHERE operation_batch_id = ?",
            (batch_id,),
        ).fetchone()
