import sqlite3


DDL = """
CREATE TABLE IF NOT EXISTS stg_qtest_projects (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    project_name TEXT,
    project_status_id INTEGER,
    project_status_name TEXT,
    defect_workflow INTEGER,
    created_date INTEGER,
    last_modified_date INTEGER,
    PRIMARY KEY (client_id, project_id)
);

CREATE TABLE IF NOT EXISTS stg_qtest_modules (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    module_id INTEGER NOT NULL,
    module_pid INTEGER,
    parent_module_id INTEGER,
    module_name TEXT,
    module_path TEXT,
    created_date INTEGER,
    last_modified_date INTEGER,
    PRIMARY KEY (client_id, module_id)
);

CREATE INDEX IF NOT EXISTS idx_modules_parent
    ON stg_qtest_modules(parent_module_id);

CREATE INDEX IF NOT EXISTS idx_modules_path
    ON stg_qtest_modules(module_path);

CREATE TABLE IF NOT EXISTS stg_qtest_test_cases (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    test_case_id INTEGER NOT NULL,
    test_case_pid INTEGER,
    test_case_name TEXT,
    input_module_id INTEGER,
    project_module_id INTEGER,
    latesttestcaseversionid INTEGER,
    module_path TEXT,
    priority_id INTEGER,
    priority_name TEXT,
    testcasetypeid INTEGER,
    testcasetype_name TEXT,
    created_date INTEGER,
    creatorid INTEGER,
    creator_name TEXT,
    last_modified_date INTEGER,
    lastmodifieduserid INTEGER,
    lastmodifiedusername TEXT,
    latestrunresultid INTEGER,
    cf_926_assigned_to TEXT,
    cf_935_test_steps TEXT,
    cf_939_comment TEXT,
    cf_940_version TEXT,
    cf_982_additional_tester TEXT,
    cf_987_application TEXT,
    cf_1008_automatable TEXT,
    cf_1019_created_by TEXT,
    cf_1022_creation_date TEXT,
    cf_1031_functional_area TEXT,
    cf_1033_number_of_steps TEXT,
    cf_1037_portfolio TEXT,
    cf_1041_product TEXT,
    cf_1049_regression TEXT,
    cf_1055_test_id TEXT,
    cf_1058_test_phase TEXT,
    cf_1527_project_id TEXT,
    cf_1528_business_function TEXT,
    cf_1535_attachments TEXT,
    PRIMARY KEY (client_id, test_case_id)
);

CREATE INDEX IF NOT EXISTS idx_test_cases_module
    ON stg_qtest_test_cases(input_module_id);

CREATE TABLE IF NOT EXISTS stg_qtest_test_case_versions (
    client_id INTEGER NOT NULL,
    test_case_version_id INTEGER NOT NULL,
    test_case_id INTEGER NOT NULL,
    test_case_version_status_id INTEGER,
    test_case_version_status_name TEXT,
    input_module_id INTEGER,
    baseline_number INTEGER,
    increase_number INTEGER,
    version TEXT,
    description TEXT,
    precondition TEXT,
    modified_date INTEGER,
    modified_user_id INTEGER,
    modifiedusername TEXT,
    deleted INTEGER,
    PRIMARY KEY (client_id, test_case_version_id)
);

CREATE INDEX IF NOT EXISTS idx_versions_test_case
    ON stg_qtest_test_case_versions(test_case_id);

CREATE INDEX IF NOT EXISTS idx_versions_module
    ON stg_qtest_test_case_versions(input_module_id);

CREATE TABLE IF NOT EXISTS stg_qtest_test_steps (
    client_id INTEGER NOT NULL,
    test_step_id INTEGER NOT NULL,
    step_order INTEGER,
    step_description TEXT,
    expected_result TEXT,
    test_case_id INTEGER,
    input_module_id INTEGER,
    test_case_version_id INTEGER NOT NULL,
    run_test_case_version_id INTEGER,
    last_modified_date INTEGER,
    last_modified_user_id INTEGER,
    lastmodifiedusername TEXT,
    stepdescriptionflag INTEGER,
    expectedresultsflag INTEGER,
    PRIMARY KEY (client_id, test_step_id)
);

CREATE INDEX IF NOT EXISTS idx_steps_version
    ON stg_qtest_test_steps(test_case_version_id);

CREATE INDEX IF NOT EXISTS idx_steps_test_case
    ON stg_qtest_test_steps(test_case_id);

CREATE TABLE IF NOT EXISTS stg_qtest_test_case_runs (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    test_run_id INTEGER NOT NULL,
    test_run_pid INTEGER,
    test_case_id INTEGER NOT NULL,
    test_case_version_id INTEGER,
    release_id INTEGER,
    test_cycle_id INTEGER,
    test_suite_id INTEGER,
    execution_type_id INTEGER,
    execution_type_name TEXT,
    priority_id INTEGER,
    priority_name TEXT,
    input_module_id INTEGER,
    module_path TEXT,
    run_name TEXT,
    runorder INTEGER,
    planned_start_date INTEGER,
    planned_end_date INTEGER,
    plannedexecutiontime INTEGER DEFAULT 0 NOT NULL,
    created_date INTEGER,
    creatorid INTEGER,
    creator_name TEXT,
    last_modified_date INTEGER,
    lastmodifieduserid INTEGER,
    lastmodifiedusername TEXT,
    userid INTEGER,
    username TEXT,
    latesttestcaseresultid INTEGER,
    projecttesttypeid INTEGER,
    projectttesttypename TEXT,
    cf_941_assigned_to TEXT,
    cf_946_execution_type TEXT,
    cf_948_environment TEXT,
    cf_951_target_release_build TEXT,
    cf_954_comment TEXT,
    cf_955_execution_status TEXT,
    cf_956_tester TEXT,
    cf_993_status TEXT,
    cf_1002_test_set_id TEXT,
    cf_1018_exec_date TEXT,
    cf_1109_executed_start TEXT,
    cf_1110_executed_end TEXT,
    cf_1111_logs TEXT,
    cf_1112_defects TEXT,
    cf_1114_ci_tool TEXT,
    cf_1133_attachments TEXT,
    cf_1134_planned_time TEXT,
    cf_1135_actual_time TEXT,
    cf_1137_build_number TEXT,
    cf_1138_build_url TEXT,
    cf_1238_location TEXT,
    cf_1250_test_release_cycle TEXT,
    cf_1255_application TEXT,
    cf_1256_new_value TEXT,
    cf_1555_test_configuration TEXT,
    PRIMARY KEY (client_id, test_run_id)
);

CREATE INDEX IF NOT EXISTS idx_runs_test_case
    ON stg_qtest_test_case_runs(test_case_id);

CREATE INDEX IF NOT EXISTS idx_runs_module
    ON stg_qtest_test_case_runs(input_module_id);

CREATE INDEX IF NOT EXISTS idx_runs_release
    ON stg_qtest_test_case_runs(release_id);

CREATE INDEX IF NOT EXISTS idx_runs_cycle
    ON stg_qtest_test_case_runs(test_cycle_id);

CREATE INDEX IF NOT EXISTS idx_runs_suite
    ON stg_qtest_test_case_runs(test_suite_id);

CREATE TABLE IF NOT EXISTS stg_qtest_releases (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    release_id INTEGER NOT NULL,
    release_pid INTEGER,
    release_name TEXT,
    releasedescription TEXT,
    release_status_id INTEGER,
    release_status_name TEXT,
    start_date INTEGER,
    end_date INTEGER,
    created_date INTEGER,
    creatorid INTEGER,
    creator_name TEXT,
    last_modified_date INTEGER,
    lastmodifieduserid INTEGER,
    lastmodifiedusername TEXT,
    note TEXT,
    cf_1005_follow_up TEXT,
    cf_1014_planned_begin_date TEXT,
    cf_1017_planned_end_date TEXT,
    cf_1251_target_release_cycle TEXT,
    cf_1525_release_note TEXT,
    PRIMARY KEY (client_id, release_id)
);

CREATE TABLE IF NOT EXISTS stg_qtest_test_cycles (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    test_cycle_id INTEGER NOT NULL,
    cycle_name TEXT,
    description TEXT,
    cycle_pid INTEGER,
    parent_cycle_id INTEGER,
    testcycletype INTEGER,
    releaseid INTEGER,
    releasename TEXT,
    created_date INTEGER,
    creatorid INTEGER,
    creator_name TEXT,
    last_modified_date INTEGER,
    lastmodifieduserid INTEGER,
    lastmodifiedusername TEXT,
    startdate INTEGER,
    enddate INTEGER,
    PRIMARY KEY (client_id, test_cycle_id)
);

CREATE TABLE IF NOT EXISTS stg_qtest_test_suites (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    test_suite_id INTEGER NOT NULL,
    suite_pid INTEGER,
    suite_name TEXT,
    description TEXT,
    test_cyle_id INTEGER,
    releaseid INTEGER,
    plannedstartdate INTEGER,
    plannedenddate INTEGER,
    created_date INTEGER,
    creatorid INTEGER,
    creator_name TEXT,
    last_modified_date INTEGER,
    lastmodifieduserid INTEGER,
    lastmodifiedusername TEXT,
    userid INTEGER,
    username TEXT,
    PRIMARY KEY (client_id, test_suite_id)
);

CREATE TABLE IF NOT EXISTS stg_qtest_test_case_results (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    test_case_result_id INTEGER NOT NULL,
    resultnumber INTEGER,
    test_run_id INTEGER NOT NULL,
    test_case_id INTEGER,
    test_case_version_id INTEGER,
    input_module_id INTEGER,
    test_execution_result_id INTEGER,
    test_execution_result_name TEXT,
    execution_type_id INTEGER,
    execution_type_name TEXT,
    user_id INTEGER,
    username TEXT,
    execution_start_date INTEGER,
    execution_end_date INTEGER,
    planned_start_date INTEGER,
    planned_end_date INTEGER,
    planned_execution_time INTEGER,
    actual_execution_time INTEGER,
    submitted_by TEXT,
    build_number TEXT,
    build_url TEXT,
    ci_system_type INTEGER,
    release_id INTEGER,
    testdatasetid INTEGER,
    assigned_userid INTEGER,
    assignedusername TEXT,
    custom_field_values TEXT,
    automation INTEGER,
    edited INTEGER,
    PRIMARY KEY (client_id, test_case_result_id)
);

CREATE INDEX IF NOT EXISTS idx_results_run
    ON stg_qtest_test_case_results(test_run_id);

CREATE INDEX IF NOT EXISTS idx_results_module
    ON stg_qtest_test_case_results(input_module_id);

CREATE TABLE IF NOT EXISTS stg_qtest_test_step_results (
    client_id INTEGER NOT NULL,
    project_id INTEGER,
    test_step_result_id INTEGER NOT NULL,
    result_order INTEGER,
    actual_result TEXT,
    test_case_result_id INTEGER NOT NULL,
    test_step_id INTEGER NOT NULL,
    test_case_id INTEGER,
    test_run_id INTEGER,
    test_case_version_id INTEGER,
    input_module_id INTEGER,
    test_execution_result_id INTEGER NOT NULL,
    called_test_case_id INTEGER,
    called_test_case_name TEXT,
    user_id INTEGER,
    username TEXT,
    tester_id INTEGER,
    testername TEXT,
    last_tester_id INTEGER,
    lasttestername TEXT,
    date INTEGER,
    executed_time INTEGER,
    last_executed_time INTEGER,
    PRIMARY KEY (client_id, test_step_result_id)
);

CREATE INDEX IF NOT EXISTS idx_step_results_case_result
    ON stg_qtest_test_step_results(test_case_result_id);

CREATE INDEX IF NOT EXISTS idx_step_results_step
    ON stg_qtest_test_step_results(test_step_id);

CREATE TABLE IF NOT EXISTS stg_qtest_test_case_result_defects (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    testcase_result_defect_link_id INTEGER NOT NULL,
    test_case_result_id INTEGER NOT NULL,
    input_module_id INTEGER,
    defect_id INTEGER,
    result_type INTEGER,
    external_issue_id TEXT,
    external_issue_summary TEXT,
    external_issue_status TEXT,
    external_issue_type TEXT,
    testcaseid INTEGER,
    testcaserunid INTEGER,
    testcaseversionid INTEGER,
    PRIMARY KEY (client_id, testcase_result_defect_link_id)
);

CREATE TABLE IF NOT EXISTS stg_qtest_test_step_result_defects (
    client_id INTEGER NOT NULL,
    test_step_result_defects_id INTEGER NOT NULL,
    test_step_result_id INTEGER NOT NULL,
    input_module_id INTEGER,
    defect_id INTEGER,
    external_defect_id TEXT,
    defect_tracking_connection_id INTEGER,
    defect_project_id TEXT,
    PRIMARY KEY (client_id, test_step_result_defects_id)
);

CREATE TABLE IF NOT EXISTS stg_qtest_defects (
    client_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    defect_id INTEGER NOT NULL,
    defect_pid INTEGER,
    summary TEXT,
    description TEXT,
    input_module_id INTEGER,
    module_id INTEGER,
    status_id INTEGER,
    status_name TEXT,
    priority_id INTEGER,
    priority_name TEXT,
    severity_id INTEGER,
    severity_name TEXT,
    type_id INTEGER,
    type_name TEXT,
    reason_id INTEGER,
    reason_name TEXT,
    root_cause_id INTEGER,
    root_cause_name TEXT,
    category_id INTEGER,
    category_name TEXT,
    affected_release_id INTEGER,
    affected_release_name TEXT,
    fixed_release_id INTEGER,
    fixed_release_name TEXT,
    target_release_id INTEGER,
    target_release_name TEXT,
    affected_build_id INTEGER,
    affected_build_name TEXT,
    fixed_build_id INTEGER,
    fixed_build_name TEXT,
    target_build_id INTEGER,
    target_build_name TEXT,
    created_by_user_id INTEGER,
    createdbyusername TEXT,
    assigned_user_id INTEGER,
    assignedusername TEXT,
    created_date INTEGER,
    target_date INTEGER,
    closed_date INTEGER,
    last_modified_date INTEGER,
    lastmodifieduserid INTEGER,
    lastmodifiedusername TEXT,
    modifieddate TEXT,
    osid INTEGER,
    browserid INTEGER,
    serverid INTEGER,
    envotherid INTEGER,
    previousstatusid INTEGER,
    previous_status_name TEXT,
    draft INTEGER,
    sourcedefectid INTEGER,
    source_defect_name TEXT,
    environmentid INTEGER,
    environment_name TEXT,
    unlinkeddefect INTEGER,
    cf_958_submitter TEXT,
    cf_961_submitted_date TEXT,
    cf_967_affected_release_build TEXT,
    cf_972_target_release_build TEXT,
    cf_975_test_target_date TEXT,
    cf_976_closed_date TEXT,
    cf_977_environment TEXT,
    cf_978_comment TEXT,
    cf_981_application TEXT,
    cf_996_detected_in_environment TEXT,
    cf_1006_portfolio TEXT,
    cf_1015_product TEXT,
    cf_1036_test_phase TEXT,
    cf_1076_functional_area TEXT,
    cf_1079_other_project_bug_id TEXT,
    cf_1082_planned_fix_date TEXT,
    cf_1083_fix_priority TEXT,
    cf_1088_root_cause_category TEXT,
    cf_1089_sub_status TEXT,
    cf_1096_vendor_reference_id TEXT,
    cf_1104_test_run_id TEXT,
    cf_1105_test_suite_id TEXT,
    cf_1106_test_run_status TEXT,
    cf_1136_attachments TEXT,
    cf_1243_business_owner TEXT,
    cf_1246_detected_in_area TEXT,
    cf_1248_technical_owner TEXT,
    cf_1249_follow_up_date TEXT,
    cf_1253_test_group TEXT,
    cf_1530_workaround_available TEXT,
    cf_1544_defect_reopen TEXT,
    PRIMARY KEY (client_id, defect_id)
);

CREATE INDEX IF NOT EXISTS idx_defects_module
    ON stg_qtest_defects(input_module_id);
"""


def run(conn: sqlite3.Connection) -> None:
    conn.executescript(DDL)
