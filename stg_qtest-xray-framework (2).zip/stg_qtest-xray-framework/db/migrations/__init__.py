import sqlite3
import importlib


MIGRATION_MODULES = [
    "db.migrations.m001_control_tables",
    "db.migrations.m002_staging_tables",
]


def run_migrations(conn: sqlite3.Connection) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS _migration_history (
            migration_name TEXT PRIMARY KEY,
            applied_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
    """)
    conn.commit()

    applied = {
        row[0]
        for row in conn.execute(
            "SELECT migration_name FROM _migration_history"
        ).fetchall()
    }

    for module_path in MIGRATION_MODULES:
        name = module_path.split(".")[-1]
        if name not in applied:
            module = importlib.import_module(module_path)
            module.run(conn)
            conn.execute(
                "INSERT INTO _migration_history (migration_name) VALUES (?)",
                (name,),
            )
            conn.commit()
