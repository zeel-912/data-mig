import sqlite3


DDL = """
CREATE TABLE IF NOT EXISTS pipeline_run (
    pipeline_run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pipeline_name TEXT NOT NULL,
    application_name TEXT NOT NULL,
    root_input_module_id INTEGER NOT NULL,
    migration_scope TEXT NOT NULL DEFAULT 'MIGRATION',
    source_project_id INTEGER,
    target_project_key TEXT NOT NULL,
    target_project_id TEXT,
    triggered_by TEXT,
    status TEXT NOT NULL DEFAULT 'PENDING',
    config_snapshot TEXT,
    started_at TEXT,
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS operation_run (
    operation_run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pipeline_run_id INTEGER NOT NULL REFERENCES pipeline_run(pipeline_run_id),
    operation_name TEXT NOT NULL,
    operation_sequence INTEGER NOT NULL,
    operation_status TEXT NOT NULL DEFAULT 'PENDING',
    dependency_gate_status TEXT DEFAULT 'PENDING',
    operation_mode TEXT DEFAULT 'FULL',
    source_count INTEGER DEFAULT 0,
    eligible_count INTEGER DEFAULT 0,
    attempted_count INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    retry_count INTEGER DEFAULT 0,
    started_at TEXT,
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS operation_batch (
    operation_batch_id INTEGER PRIMARY KEY AUTOINCREMENT,
    operation_run_id INTEGER NOT NULL REFERENCES operation_run(operation_run_id),
    pipeline_run_id INTEGER NOT NULL,
    batch_number INTEGER NOT NULL,
    wave_number INTEGER,
    batch_status TEXT NOT NULL DEFAULT 'PENDING',
    source_record_count INTEGER DEFAULT 0,
    attempted_count INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    retry_count INTEGER DEFAULT 0,
    started_at TEXT,
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS id_mapping (
    mapping_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pipeline_run_id INTEGER NOT NULL,
    operation_run_id INTEGER NOT NULL,
    source_entity_type TEXT NOT NULL,
    source_id TEXT NOT NULL,
    target_entity_type TEXT NOT NULL,
    target_id TEXT,
    target_key TEXT,
    target_path TEXT,
    relationship_context TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_id_mapping_source
    ON id_mapping(source_entity_type, source_id);

CREATE INDEX IF NOT EXISTS idx_id_mapping_operation
    ON id_mapping(operation_run_id);

CREATE INDEX IF NOT EXISTS idx_id_mapping_pipeline
    ON id_mapping(pipeline_run_id);

CREATE TABLE IF NOT EXISTS failed_record (
    failed_record_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pipeline_run_id INTEGER NOT NULL,
    operation_run_id INTEGER NOT NULL,
    operation_batch_id INTEGER,
    operation_name TEXT NOT NULL,
    source_entity_type TEXT NOT NULL,
    primary_source_id TEXT NOT NULL,
    related_source_ids_json TEXT,
    source_context_json TEXT,
    target_context_json TEXT,
    payload_snapshot_json TEXT,
    error_code TEXT,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    failure_status TEXT DEFAULT 'UNRESOLVED',
    resolved_at TEXT,
    resolved_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_failed_record_operation
    ON failed_record(operation_run_id, failure_status);

CREATE INDEX IF NOT EXISTS idx_failed_record_pipeline
    ON failed_record(pipeline_run_id, operation_name);

CREATE TABLE IF NOT EXISTS reconciliation_summary (
    reconciliation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pipeline_run_id INTEGER NOT NULL,
    operation_run_id INTEGER NOT NULL,
    operation_name TEXT NOT NULL,
    source_count INTEGER DEFAULT 0,
    eligible_count INTEGER DEFAULT 0,
    attempted_count INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    mapped_count INTEGER DEFAULT 0,
    unresolved_count INTEGER DEFAULT 0,
    status TEXT,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_reconciliation_operation
    ON reconciliation_summary(operation_run_id);
"""


def run(conn: sqlite3.Connection) -> None:
    conn.executescript(DDL)
