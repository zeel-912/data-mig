from common.models import SourceRecord


def build_move_to_folder_payload(record: SourceRecord) -> dict:
    """Build addTestsToFolder GraphQL args from a resolved move record."""
    return {
        "folderId": record.data["folder_id"],
        "testIssueIds": [record.data["xray_issue_id"]],
    }
