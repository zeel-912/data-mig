import sqlite3


GET_PRECONDITIONS_FOR_PROJECT = """
    SELECT
        tcv.test_case_version_id,
        tcv.test_case_id,
        tcv.precondition,
        tcv.version,
        tcv.input_module_id,
        tc.test_case_name,
        tc.module_path
    FROM stg_qtest_test_case_versions tcv
    JOIN stg_qtest_test_cases tc
        ON tcv.client_id = tc.client_id
        AND tcv.test_case_id = tc.test_case_id
    WHERE tc.project_id = (
        SELECT project_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND tc.client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND tcv.test_case_version_id = tc.latesttestcaseversionid
    AND tcv.precondition IS NOT NULL
    AND TRIM(tcv.precondition) != ''
    AND (tcv.deleted IS NULL OR tcv.deleted = 0)
    ORDER BY tcv.test_case_version_id
"""

GET_PRECONDITION_COUNT = """
    SELECT COUNT(*) as cnt
    FROM stg_qtest_test_case_versions tcv
    JOIN stg_qtest_test_cases tc
        ON tcv.client_id = tc.client_id
        AND tcv.test_case_id = tc.test_case_id
    WHERE tc.project_id = (
        SELECT project_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND tc.client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND tcv.test_case_version_id = tc.latesttestcaseversionid
    AND tcv.precondition IS NOT NULL
    AND TRIM(tcv.precondition) != ''
    AND (tcv.deleted IS NULL OR tcv.deleted = 0)
"""


def get_preconditions_for_project(
    conn: sqlite3.Connection, root_module_id: int
) -> list[sqlite3.Row]:
    return conn.execute(
        GET_PRECONDITIONS_FOR_PROJECT, (root_module_id, root_module_id)
    ).fetchall()


def get_precondition_count(conn: sqlite3.Connection, root_module_id: int) -> int:
    row = conn.execute(
        GET_PRECONDITION_COUNT, (root_module_id, root_module_id)
    ).fetchone()
    return row["cnt"] if row else 0
