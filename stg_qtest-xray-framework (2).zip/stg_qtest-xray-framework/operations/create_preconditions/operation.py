from functools import partial
from loguru import logger

from config.operations import OperationName
from operations.base import BaseOperation
from operations.registry import register_operation
from operations.create_preconditions.queries import (
    get_preconditions_for_project,
    get_precondition_count,
)
from operations.create_preconditions.transformer import build_precondition_payload
from common.models import SourceRecord, OperationResult, ApiCall, CallResult
from common.batch_executor import WaveExecutor


@register_operation(OperationName.CREATE_PRECONDITIONS)
class CreatePreconditionsOperation(BaseOperation):
    """Create Xray Precondition issues from qTest test case version precondition fields.

    One Xray Precondition per test_case_version that has a non-empty precondition field.
    Wave-based execution: 40 calls × 12 resolvers = 480 records/wave.
    NO folder mapping — folder assignment is a separate operation.
    """

    MUTATION_TEMPLATE = "createTest"
    RETURN_FIELDS = '{ issueId jira(fields: ["key"]) { key } }'

    def extract(self) -> list[SourceRecord]:
        rows = get_preconditions_for_project(self.conn, self.context.root_input_module_id)

        records = []
        for row in rows:
            version_id = str(row["test_case_version_id"])
            if self.mapping_repo.mapping_exists("PRECONDITION", version_id):
                continue
            records.append(SourceRecord(
                source_entity_type="PRECONDITION",
                source_id=version_id,
                data={
                    "test_case_version_id": row["test_case_version_id"],
                    "test_case_id": row["test_case_id"],
                    "precondition": row["precondition"],
                    "version": row["version"],
                    "test_case_name": row["test_case_name"],
                    "module_path": row["module_path"],
                    "input_module_id": row["input_module_id"],
                },
            ))

        return records

    def transform(self, records: list[SourceRecord]) -> list[dict]:
        return [build_precondition_payload(r.data) for r in records]

    async def load(self, records: list[SourceRecord]) -> OperationResult:
        """Create preconditions via wave-based execution."""
        wave_executor = WaveExecutor(
            concurrency=self.settings.wave.concurrency,
            resolvers_per_call=self._get_resolvers_per_call(),
            retry_resolvers_per_call=self.settings.wave.retry_resolvers_per_call,
            max_retry_rounds=self.settings.wave.max_retries_per_wave,
        )

        api_fn = partial(self._execute_call)
        return await wave_executor.execute_all_waves(records, api_fn)

    async def _execute_call(self, call: ApiCall) -> CallResult:
        """Execute a single batched GraphQL call for preconditions."""
        return await self.xray_client.execute_api_call(
            call=call,
            mutation_template=self.MUTATION_TEMPLATE,
            record_to_args_fn=self._record_to_args,
            alias_prefix="pc",
            return_fields=self.RETURN_FIELDS,
            target_id_field="issueId",
            target_key_field="key",
        )

    def _record_to_args(self, record: SourceRecord) -> dict:
        """Convert a SourceRecord to GraphQL mutation arguments."""
        return build_precondition_payload(record.data)

    def get_source_count(self) -> int:
        return get_precondition_count(self.conn, self.context.root_input_module_id)

    def _get_target_entity_type(self) -> str:
        return "XRAY_PRECONDITION"
