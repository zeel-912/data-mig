import sqlite3


def build_precondition_payload(row: sqlite3.Row) -> dict:
    """Build Xray createTest GraphQL args for a precondition.

    Xray preconditions are created as testType: {name: "Generic"} with
    the precondition text as the Jira issue description.
    No folder mapping — that happens in MOVE_PRECONDITIONS_TO_FOLDERS.
    """
    precondition_text = (row["precondition"] or "").strip()
    test_case_name = row["test_case_name"] or "Untitled"
    version = row["version"] or ""

    summary = f"[Precondition] {test_case_name}"
    if version:
        summary = f"[Precondition] {test_case_name} (v{version})"

    if len(summary) > 255:
        summary = summary[:252] + "..."

    return {
        "testType": {"name": "Generic"},
        "jira": {
            "fields": {
                "summary": summary,
                "description": precondition_text,
            }
        },
    }
