from config.operations import OperationName
from operations.base import BaseOperation

_REGISTRY: dict[OperationName, type[BaseOperation]] = {}


def register_operation(name: OperationName):
    """Decorator to register an operation class."""
    def decorator(cls: type[BaseOperation]):
        _REGISTRY[name] = cls
        cls.operation_name = name
        return cls
    return decorator


def get_operation_class(name: OperationName) -> type[BaseOperation] | None:
    return _REGISTRY.get(name)


def get_registered_operations() -> dict[OperationName, type[BaseOperation]]:
    return dict(_REGISTRY)
