import sqlite3


GET_UNMOVED_TEST_CASES = """
    SELECT
        im.source_id AS test_case_id,
        im.target_id AS xray_issue_id,
        im.target_key AS xray_issue_key,
        tc.input_module_id,
        tc.module_path
    FROM id_mapping im
    JOIN stg_qtest_test_cases tc
        ON im.source_id = CAST(tc.test_case_id AS TEXT)
        AND tc.client_id = (
            SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
        )
    WHERE im.source_entity_type = 'TEST_CASE'
    AND im.target_entity_type = 'XRAY_TEST'
    AND NOT EXISTS (
        SELECT 1 FROM id_mapping moved
        WHERE moved.source_entity_type = 'TEST_CASE_FOLDER_MOVE'
        AND moved.source_id = im.source_id
    )
    ORDER BY tc.module_path
"""

GET_FOLDER_MAPPING = """
    SELECT
        im.target_path AS folder_path,
        im.target_id AS folder_id
    FROM id_mapping im
    WHERE im.source_entity_type = 'MODULE'
    AND im.target_entity_type = 'XRAY_FOLDER'
    AND im.pipeline_run_id IN (
        SELECT pipeline_run_id FROM pipeline_run
        WHERE application_name = ?
    )
"""


def get_unmoved_test_cases(
    conn: sqlite3.Connection, root_module_id: int
) -> list[sqlite3.Row]:
    return conn.execute(
        GET_UNMOVED_TEST_CASES, (root_module_id,)
    ).fetchall()


def get_folder_mapping(
    conn: sqlite3.Connection, application_name: str
) -> dict[str, str]:
    """Returns {normalized_folder_path: folder_id} from id_mapping."""
    rows = conn.execute(GET_FOLDER_MAPPING, (application_name,)).fetchall()
    return {row["folder_path"]: row["folder_id"] for row in rows if row["folder_path"]}
