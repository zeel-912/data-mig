from common.models import SourceRecord


def build_link_precondition_payload(record: SourceRecord) -> dict:
    """Build addPreconditionsToTest GraphQL args from a resolved link record."""
    return {
        "issueId": record.data["test_issue_id"],
        "preconditionIssueIds": [record.data["precondition_issue_id"]],
    }
