import sqlite3


GET_UNLINKED_PRECONDITIONS = """
    SELECT
        pc_map.source_id AS precondition_version_id,
        pc_map.target_id AS precondition_issue_id,
        pc_map.target_key AS precondition_issue_key,
        tcv.test_case_id,
        tc_map.target_id AS test_issue_id,
        tc_map.target_key AS test_issue_key
    FROM id_mapping pc_map
    JOIN stg_qtest_test_case_versions tcv
        ON pc_map.source_id = CAST(tcv.test_case_version_id AS TEXT)
        AND tcv.client_id = (
            SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
        )
    JOIN id_mapping tc_map
        ON tc_map.source_id = CAST(tcv.test_case_id AS TEXT)
        AND tc_map.source_entity_type = 'TEST_CASE'
        AND tc_map.target_entity_type = 'XRAY_TEST'
    WHERE pc_map.source_entity_type = 'PRECONDITION'
    AND pc_map.target_entity_type = 'XRAY_PRECONDITION'
    AND NOT EXISTS (
        SELECT 1 FROM id_mapping linked
        WHERE linked.source_entity_type = 'PRECONDITION_LINK'
        AND linked.source_id = pc_map.source_id
    )
    ORDER BY tcv.test_case_id
"""


def get_unlinked_preconditions(
    conn: sqlite3.Connection, root_module_id: int
) -> list[sqlite3.Row]:
    return conn.execute(GET_UNLINKED_PRECONDITIONS, (root_module_id,)).fetchall()
