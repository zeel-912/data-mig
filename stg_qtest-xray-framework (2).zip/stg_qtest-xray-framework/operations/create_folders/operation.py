from functools import partial
from loguru import logger

from config.operations import OperationName
from operations.base import BaseOperation
from operations.registry import register_operation
from operations.create_folders.queries import get_modules_for_root, get_module_count
from operations.create_folders.transformer import build_folder_paths
from common.models import SourceRecord, OperationResult, ApiCall, CallResult
from common.batch_executor import WaveExecutor


@register_operation(OperationName.CREATE_FOLDERS)
class CreateFoldersOperation(BaseOperation):
    """Create Xray Test Repository folders from qTest modules.

    Wave-based execution with 25 resolvers/call.
    Xray createFolder handles full paths (creates intermediates automatically).
    Records are depth-ordered (shallowest first) for clarity.
    """

    MUTATION_TEMPLATE = "createFolder"
    RETURN_FIELDS = "{ folder { path name } }"

    def extract(self) -> list[SourceRecord]:
        modules = get_modules_for_root(self.conn, self.context.root_input_module_id)
        folder_data = build_folder_paths(modules)

        records = []
        for fd in folder_data:
            if self.mapping_repo.mapping_exists("MODULE", fd["module_id"]):
                continue
            records.append(SourceRecord(
                source_entity_type="MODULE",
                source_id=fd["module_id"],
                data=fd,
            ))

        return records

    def transform(self, records: list[SourceRecord]) -> list[dict]:
        return [
            {
                "projectId": self.context.target_project_key,
                "path": r.data["path"],
            }
            for r in records
        ]

    async def load(self, records: list[SourceRecord]) -> OperationResult:
        """Create folders via wave-based execution."""
        wave_executor = WaveExecutor(
            concurrency=self.settings.wave.concurrency,
            resolvers_per_call=self._get_resolvers_per_call(),
            retry_resolvers_per_call=self.settings.wave.retry_resolvers_per_call,
            max_retry_rounds=self.settings.wave.max_retries_per_wave,
        )

        api_fn = partial(self._execute_call)
        return await wave_executor.execute_all_waves(records, api_fn)

    async def _execute_call(self, call: ApiCall) -> CallResult:
        """Execute a single batched GraphQL call for folder creation."""
        return await self.xray_client.execute_api_call(
            call=call,
            mutation_template=self.MUTATION_TEMPLATE,
            record_to_args_fn=self._record_to_args,
            alias_prefix="f",
            return_fields=self.RETURN_FIELDS,
            target_id_field=None,
            target_path_field="path",
        )

    def _record_to_args(self, record: SourceRecord) -> dict:
        return {
            "projectId": self.context.target_project_key,
            "path": record.data["path"],
        }

    def get_source_count(self) -> int:
        return get_module_count(self.conn, self.context.root_input_module_id)

    def _get_target_entity_type(self) -> str:
        return "XRAY_FOLDER"
