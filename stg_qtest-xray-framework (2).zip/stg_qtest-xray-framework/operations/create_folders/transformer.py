import sqlite3


def build_folder_paths(modules: list[sqlite3.Row]) -> list[dict]:
    """Build normalized, deduplicated, depth-ordered folder paths from module data.

    Returns list of dicts with 'module_id', 'path', 'depth' sorted shallowest first.
    """
    paths_seen: set[str] = set()
    result: list[dict] = []

    for module in modules:
        raw_path = module["module_path"]
        if not raw_path:
            continue

        path = normalize_path(raw_path)
        if not path or path in paths_seen:
            continue

        paths_seen.add(path)
        depth = path.count("/")
        result.append({
            "module_id": str(module["module_id"]),
            "path": path,
            "depth": depth,
            "module_name": module["module_name"],
        })

    result.sort(key=lambda x: x["depth"])
    return result


def normalize_path(raw_path: str) -> str:
    """Normalize a folder path: leading /, no trailing /, clean separators."""
    path = raw_path.strip()

    path = path.replace("\\", "/")

    while "//" in path:
        path = path.replace("//", "/")

    if not path.startswith("/"):
        path = "/" + path

    if path.endswith("/") and len(path) > 1:
        path = path.rstrip("/")

    return path
