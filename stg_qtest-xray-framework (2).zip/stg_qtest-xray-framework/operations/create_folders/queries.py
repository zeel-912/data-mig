import sqlite3


GET_MODULES_FOR_ROOT = """
    SELECT module_id, module_pid, parent_module_id, module_name, module_path
    FROM stg_qtest_modules
    WHERE client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND module_path LIKE (
        SELECT module_path FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    ) || '%'
    ORDER BY LENGTH(module_path) - LENGTH(REPLACE(module_path, '/', ''))
"""

GET_ALL_MODULES_FOR_PROJECT = """
    SELECT module_id, module_pid, parent_module_id, module_name, module_path
    FROM stg_qtest_modules
    WHERE project_id = (
        SELECT project_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    ORDER BY LENGTH(module_path) - LENGTH(REPLACE(module_path, '/', ''))
"""

GET_MODULE_COUNT = """
    SELECT COUNT(*) as cnt
    FROM stg_qtest_modules
    WHERE project_id = (
        SELECT project_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
"""


def get_modules_for_root(conn: sqlite3.Connection, root_module_id: int) -> list[sqlite3.Row]:
    return conn.execute(GET_ALL_MODULES_FOR_PROJECT, (root_module_id, root_module_id)).fetchall()


def get_module_count(conn: sqlite3.Connection, root_module_id: int) -> int:
    row = conn.execute(GET_MODULE_COUNT, (root_module_id, root_module_id)).fetchone()
    return row["cnt"] if row else 0
