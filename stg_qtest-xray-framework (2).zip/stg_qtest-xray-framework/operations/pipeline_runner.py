import sqlite3
from loguru import logger

from config.settings import Settings
from config.operations import (
    OperationName,
    ExecutionMode,
    OPERATION_SEQUENCE,
)
from operations.base import PipelineContext, BaseOperation
from operations.registry import get_operation_class
from db.repositories.pipeline_repo import PipelineRepo
from db.repositories.operation_repo import OperationRepo
from db.repositories.failed_record_repo import FailedRecordRepo
from common.exceptions import DependencyGateError


class PipelineRunner:
    """Orchestrates operation execution with dependency gate checking."""

    def __init__(
        self,
        conn: sqlite3.Connection,
        settings: Settings,
        xray_client=None,
        jira_client=None,
    ):
        self.conn = conn
        self.settings = settings
        self.xray_client = xray_client
        self.jira_client = jira_client
        self.pipeline_repo = PipelineRepo(conn)
        self.operation_repo = OperationRepo(conn)
        self.failed_record_repo = FailedRecordRepo(conn)

    async def run_full_pipeline(self, context: PipelineContext):
        """Run all operations in sequence with dependency gates."""
        logger.info(
            f"Starting full pipeline for application={context.application_name}, "
            f"module={context.root_input_module_id}"
        )

        for op_name in OPERATION_SEQUENCE:
            op_class = get_operation_class(op_name)
            if op_class is None:
                logger.warning(f"Operation {op_name.value} not implemented, skipping")
                continue

            self._check_dependency_gate(context, op_name)

            operation = self._create_operation(op_class, context)
            result = await operation.run()

            if not result.gate_passed:
                logger.warning(
                    f"Operation {op_name.value} has unresolved failures. "
                    f"Pipeline halted. Resolve failures and retry."
                )
                self.pipeline_repo.update_status(
                    context.pipeline_run_id, "GATE_BLOCKED"
                )
                return

        self.pipeline_repo.update_status(context.pipeline_run_id, "COMPLETED")
        logger.info("Pipeline completed successfully")

    async def run_single_operation(
        self, context: PipelineContext, operation_name: OperationName
    ):
        """Run a single operation (OPERATION_ONLY mode)."""
        logger.info(f"Running single operation: {operation_name.value}")

        op_class = get_operation_class(operation_name)
        if op_class is None:
            raise ValueError(f"Operation {operation_name.value} not implemented")

        self._check_dependency_gate(context, operation_name)

        operation = self._create_operation(op_class, context)
        result = await operation.run()

        if result.gate_passed:
            logger.info(f"Operation {operation_name.value} completed, gate PASSED")
        else:
            logger.warning(
                f"Operation {operation_name.value} has {result.total_failed} unresolved failures"
            )

        return result

    async def run_failed_records(
        self, context: PipelineContext, operation_name: OperationName
    ):
        """Retry failed records for a specific operation."""
        logger.info(f"Retrying failed records for: {operation_name.value}")

        op_class = get_operation_class(operation_name)
        if op_class is None:
            raise ValueError(f"Operation {operation_name.value} not implemented")

        context.mode = ExecutionMode.FAILED_RECORDS
        operation = self._create_operation(op_class, context)
        result = await operation.run()
        return result

    def _check_dependency_gate(
        self, context: PipelineContext, operation_name: OperationName
    ) -> None:
        """Check that all previous operations in the sequence have passed their gates."""
        try:
            op_index = OPERATION_SEQUENCE.index(operation_name)
        except ValueError:
            return

        for i in range(op_index):
            prev_op_name = OPERATION_SEQUENCE[i]
            prev_run = self.operation_repo.get_latest_for_operation(
                context.pipeline_run_id, prev_op_name.value
            )

            if prev_run is None:
                continue

            if prev_run["dependency_gate_status"] == "BLOCKED":
                unresolved = self.failed_record_repo.get_unresolved_count(
                    prev_run["operation_run_id"]
                )
                if unresolved > 0:
                    raise DependencyGateError(
                        f"Cannot run {operation_name.value}: "
                        f"previous operation {prev_op_name.value} has "
                        f"{unresolved} unresolved failures",
                        blocking_operation=prev_op_name.value,
                    )

    def _create_operation(
        self, op_class: type[BaseOperation], context: PipelineContext
    ) -> BaseOperation:
        return op_class(
            conn=self.conn,
            context=context,
            xray_client=self.xray_client,
            jira_client=self.jira_client,
            settings=self.settings,
        )
