from operations.base import BaseOperation, PipelineContext
from operations.registry import register_operation, get_operation_class
from operations.pipeline_runner import PipelineRunner

import operations.create_folders.operation  # noqa: F401 — registers the operation
import operations.create_preconditions.operation  # noqa: F401 — registers the operation
import operations.create_test_cases.operation  # noqa: F401 — registers the operation
import operations.move_preconditions_to_folders.operation  # noqa: F401 — registers the operation
import operations.move_tests_to_folders.operation  # noqa: F401 — registers the operation
import operations.link_preconditions_to_tests.operation  # noqa: F401 — registers the operation

__all__ = [
    "BaseOperation",
    "PipelineContext",
    "PipelineRunner",
    "register_operation",
    "get_operation_class",
]
