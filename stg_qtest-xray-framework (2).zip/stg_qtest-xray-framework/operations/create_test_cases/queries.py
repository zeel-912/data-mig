import sqlite3


GET_TEST_CASES_FOR_PROJECT = """
    SELECT
        tc.test_case_id,
        tc.test_case_name,
        tc.module_path,
        tc.input_module_id,
        tc.priority_name,
        tc.latesttestcaseversionid,
        tcv.test_case_version_id,
        tcv.version,
        tcv.description
    FROM stg_qtest_test_cases tc
    JOIN stg_qtest_test_case_versions tcv
        ON tc.client_id = tcv.client_id
        AND tc.test_case_id = tcv.test_case_id
        AND tcv.test_case_version_id = tc.latesttestcaseversionid
    WHERE tc.project_id = (
        SELECT project_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND tc.client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND (tcv.deleted IS NULL OR tcv.deleted = 0)
    ORDER BY tc.test_case_id
"""

GET_TEST_STEPS_FOR_VERSIONS = """
    SELECT
        test_step_id,
        test_case_version_id,
        step_order,
        step_description,
        expected_result
    FROM stg_qtest_test_steps
    WHERE client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND test_case_version_id IN ({placeholders})
    ORDER BY test_case_version_id, step_order
"""

GET_TEST_CASE_COUNT = """
    SELECT COUNT(*) as cnt
    FROM stg_qtest_test_cases tc
    JOIN stg_qtest_test_case_versions tcv
        ON tc.client_id = tcv.client_id
        AND tc.test_case_id = tcv.test_case_id
        AND tcv.test_case_version_id = tc.latesttestcaseversionid
    WHERE tc.project_id = (
        SELECT project_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND tc.client_id = (
        SELECT client_id FROM stg_qtest_modules WHERE module_id = ? LIMIT 1
    )
    AND (tcv.deleted IS NULL OR tcv.deleted = 0)
"""


def get_test_cases_for_project(
    conn: sqlite3.Connection, root_module_id: int
) -> list[sqlite3.Row]:
    return conn.execute(
        GET_TEST_CASES_FOR_PROJECT, (root_module_id, root_module_id)
    ).fetchall()


def get_test_steps_for_versions(
    conn: sqlite3.Connection, root_module_id: int, version_ids: list[int]
) -> list[sqlite3.Row]:
    if not version_ids:
        return []
    placeholders = ",".join("?" for _ in version_ids)
    query = GET_TEST_STEPS_FOR_VERSIONS.format(placeholders=placeholders)
    params = [root_module_id] + version_ids
    return conn.execute(query, params).fetchall()


def get_test_case_count(conn: sqlite3.Connection, root_module_id: int) -> int:
    row = conn.execute(
        GET_TEST_CASE_COUNT, (root_module_id, root_module_id)
    ).fetchone()
    return row["cnt"] if row else 0
