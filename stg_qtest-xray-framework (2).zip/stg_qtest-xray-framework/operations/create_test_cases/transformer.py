import sqlite3


def build_test_case_payload(test_case: dict, steps: list[dict]) -> dict:
    """Build Xray createTest GraphQL args for a Manual test case with steps.

    No folder mapping — that happens in MOVE_TESTS_TO_FOLDERS.
    """
    summary = test_case["test_case_name"] or "Untitled Test"
    if len(summary) > 255:
        summary = summary[:252] + "..."

    description = test_case.get("description") or ""
    priority = test_case.get("priority_name")

    jira_fields = {
        "summary": summary,
    }
    if description:
        jira_fields["description"] = description
    if priority:
        jira_fields["priority"] = {"name": priority}

    payload = {
        "testType": {"name": "Manual"},
        "jira": {"fields": jira_fields},
    }

    if steps:
        payload["steps"] = _build_steps(steps)

    return payload


def _build_steps(steps: list[dict]) -> list[dict]:
    """Convert qTest steps to Xray step format."""
    xray_steps = []
    for step in steps:
        action = step.get("step_description") or ""
        expected = step.get("expected_result") or ""
        xray_steps.append({
            "action": action,
            "result": expected,
        })
    return xray_steps
