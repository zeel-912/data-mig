import asyncio
import time
import random
from loguru import logger


class RateLimiter:
    """Rate limiter with token bucket, Retry-After handling, and adaptive slowdown.

    Handles:
    - Burst control via token bucket (configurable requests/second)
    - Retry-After header pause (blocks ALL calls for the specified duration)
    - X-RateLimit-NearLimit adaptive slowdown
    - Exponential backoff with jitter for 429 responses
    """

    def __init__(
        self,
        requests_per_second: float = 50.0,
        burst_size: int = 50,
    ):
        self._rate = requests_per_second
        self._burst_size = burst_size
        self._tokens = float(burst_size)
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()
        self._global_pause_until: float = 0.0
        self._near_limit = False
        self._consecutive_429s = 0

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()

            if now < self._global_pause_until:
                wait_time = self._global_pause_until - now
                logger.warning(
                    f"Rate limiter: global pause active, waiting {wait_time:.1f}s"
                )
                await asyncio.sleep(wait_time)
                now = time.monotonic()

            elapsed = now - self._last_refill
            self._tokens = min(
                self._burst_size,
                self._tokens + elapsed * self._rate,
            )
            self._last_refill = now

            if self._tokens < 1.0:
                wait_time = (1.0 - self._tokens) / self._rate
                await asyncio.sleep(wait_time)
                self._tokens = 0.0
                self._last_refill = time.monotonic()
            else:
                self._tokens -= 1.0

            if self._near_limit:
                await asyncio.sleep(0.2)

    def notify_response(self, status_code: int, headers: dict) -> None:
        retry_after = headers.get("Retry-After") or headers.get("retry-after")
        near_limit = headers.get("X-RateLimit-NearLimit") or headers.get(
            "x-ratelimit-nearlimit"
        )

        if near_limit and near_limit.lower() == "true":
            self._near_limit = True
            logger.warning("Rate limiter: near-limit detected, slowing down")
        elif self._near_limit and status_code < 400:
            self._near_limit = False

        if status_code == 429:
            self._consecutive_429s += 1
            pause_seconds = self._calculate_backoff(retry_after)
            self._global_pause_until = time.monotonic() + pause_seconds
            logger.warning(
                f"Rate limiter: 429 received (consecutive={self._consecutive_429s}), "
                f"pausing all requests for {pause_seconds:.1f}s"
            )
        elif status_code < 400:
            self._consecutive_429s = 0

    def _calculate_backoff(self, retry_after: str | None) -> float:
        if retry_after:
            try:
                return float(retry_after)
            except (ValueError, TypeError):
                pass

        base_delay = 2.0
        delay = base_delay * (2 ** min(self._consecutive_429s, 4))
        jitter = random.uniform(0.7, 1.3)
        return delay * jitter

    @property
    def is_paused(self) -> bool:
        return time.monotonic() < self._global_pause_until

    def reset(self) -> None:
        self._tokens = float(self._burst_size)
        self._last_refill = time.monotonic()
        self._global_pause_until = 0.0
        self._near_limit = False
        self._consecutive_429s = 0
