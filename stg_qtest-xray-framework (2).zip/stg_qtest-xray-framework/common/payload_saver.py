import json
from pathlib import Path
from loguru import logger

from common.models import CallResult, WaveResult


class PayloadSaver:
    """Saves per-call payloads (request, response, results) to disk for audit/debug."""

    def __init__(self, base_dir: str, pipeline_run_id: int, operation_name: str):
        self._base_path = (
            Path(base_dir) / f"run_{pipeline_run_id}" / operation_name
        )

    def save_wave(self, wave_result: WaveResult) -> None:
        wave_dir = self._base_path / f"wave_{wave_result.wave_number}"
        wave_dir.mkdir(parents=True, exist_ok=True)

        for call_result in wave_result.call_results:
            self._save_call(wave_dir, call_result)

    def _save_call(self, wave_dir: Path, call_result: CallResult) -> None:
        call_id = call_result.call_id

        if call_result.raw_request:
            request_path = wave_dir / f"call_{call_id}_request.json"
            request_path.write_text(
                json.dumps({"query": call_result.raw_request}, indent=2),
                encoding="utf-8",
            )

        if call_result.raw_response:
            response_path = wave_dir / f"call_{call_id}_response.json"
            response_path.write_text(
                json.dumps(call_result.raw_response, indent=2, default=str),
                encoding="utf-8",
            )

        results_path = wave_dir / f"call_{call_id}_results.json"
        results_data = {
            "call_id": call_id,
            "status": call_result.status.value,
            "duration_ms": call_result.duration_ms,
            "successes": [
                {
                    "source_id": r.source_record.source_id,
                    "source_entity_type": r.source_record.source_entity_type,
                    "target_id": r.target_id,
                    "target_key": r.target_key,
                    "target_path": r.target_path,
                }
                for r in call_result.successes
            ],
            "failures": [
                {
                    "source_id": r.source_record.source_id,
                    "source_entity_type": r.source_record.source_entity_type,
                    "error_code": r.error_code,
                    "error_message": r.error_message,
                }
                for r in call_result.failures
            ],
        }
        results_path.write_text(
            json.dumps(results_data, indent=2, default=str),
            encoding="utf-8",
        )

    def save_all(self, wave_results: list[WaveResult], retry_wave_results: list[WaveResult] | None = None) -> None:
        for wave_result in wave_results:
            self.save_wave(wave_result)

        if retry_wave_results:
            for wave_result in retry_wave_results:
                retry_dir = self._base_path / f"retry_wave_{wave_result.wave_number}"
                retry_dir.mkdir(parents=True, exist_ok=True)
                for call_result in wave_result.call_results:
                    self._save_call(retry_dir, call_result)

        logger.info(
            f"[PayloadSaver] Saved payloads to {self._base_path}"
        )
