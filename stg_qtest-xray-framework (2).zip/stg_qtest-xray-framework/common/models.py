from dataclasses import dataclass, field
from enum import Enum


@dataclass
class SourceRecord:
    source_entity_type: str
    source_id: str
    data: dict = field(default_factory=dict)


@dataclass
class ApiCall:
    call_id: int
    records: list[SourceRecord] = field(default_factory=list)

    @property
    def record_count(self) -> int:
        return len(self.records)


@dataclass
class Wave:
    wave_number: int
    calls: list[ApiCall] = field(default_factory=list)

    @property
    def total_records(self) -> int:
        return sum(c.record_count for c in self.calls)

    @property
    def call_count(self) -> int:
        return len(self.calls)


class CallStatus(str, Enum):
    SUCCESS = "SUCCESS"
    PARTIAL_SUCCESS = "PARTIAL_SUCCESS"
    FAILED = "FAILED"
    RATE_LIMITED = "RATE_LIMITED"
    TIMEOUT = "TIMEOUT"


@dataclass
class RecordResult:
    source_record: SourceRecord
    success: bool
    target_id: str | None = None
    target_key: str | None = None
    target_path: str | None = None
    error_code: str | None = None
    error_message: str | None = None
    raw_response: dict | None = None


@dataclass
class CallResult:
    call_id: int
    status: CallStatus
    successes: list[RecordResult] = field(default_factory=list)
    failures: list[RecordResult] = field(default_factory=list)
    raw_request: str | None = None
    raw_response: dict | None = None
    duration_ms: float = 0.0
    retry_after_seconds: float | None = None


@dataclass
class WaveResult:
    wave_number: int
    call_results: list[CallResult] = field(default_factory=list)

    @property
    def total_success(self) -> int:
        return sum(len(cr.successes) for cr in self.call_results)

    @property
    def total_failed(self) -> int:
        return sum(len(cr.failures) for cr in self.call_results)

    @property
    def failed_records(self) -> list[RecordResult]:
        failed = []
        for cr in self.call_results:
            failed.extend(cr.failures)
        return failed

    @property
    def successful_records(self) -> list[RecordResult]:
        successful = []
        for cr in self.call_results:
            successful.extend(cr.successes)
        return successful


@dataclass
class OperationResult:
    total_source: int = 0
    total_attempted: int = 0
    total_success: int = 0
    total_failed: int = 0
    total_retried: int = 0
    wave_results: list[WaveResult] = field(default_factory=list)
    retry_wave_results: list[WaveResult] = field(default_factory=list)
    all_successes: list[RecordResult] = field(default_factory=list)
    all_failures: list[RecordResult] = field(default_factory=list)

    @property
    def gate_passed(self) -> bool:
        return self.total_failed == 0
