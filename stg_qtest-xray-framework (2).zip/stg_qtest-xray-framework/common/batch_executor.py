import asyncio
import time
from typing import Callable, Awaitable
from loguru import logger

from common.models import (
    SourceRecord,
    ApiCall,
    Wave,
    CallResult,
    CallStatus,
    WaveResult,
    OperationResult,
    RecordResult,
)


class WaveExecutor:
    """Core wave-based concurrency engine.

    Groups records into calls (resolvers_per_call each),
    groups calls into waves (concurrency calls per wave),
    fires each wave with asyncio.gather (wave-blocking),
    and auto-retries failed records with lower resolvers after all waves.

    Flow:
        records -> calls (12/call) -> waves (40 calls/wave)
        -> fire wave (gather 40 concurrent calls)
        -> wait ALL complete
        -> collect successes/failures
        -> next wave
        -> after ALL waves: retry failures with lower resolvers
        -> return OperationResult
    """

    def __init__(
        self,
        concurrency: int = 40,
        resolvers_per_call: int = 12,
        retry_resolvers_per_call: int = 4,
        max_retry_rounds: int = 2,
    ):
        self.concurrency = concurrency
        self.resolvers_per_call = resolvers_per_call
        self.retry_resolvers_per_call = retry_resolvers_per_call
        self.max_retry_rounds = max_retry_rounds

    def build_waves(
        self, records: list[SourceRecord], resolvers_per_call: int | None = None
    ) -> list[Wave]:
        rpc = resolvers_per_call or self.resolvers_per_call
        calls: list[ApiCall] = []
        call_id = 0

        for i in range(0, len(records), rpc):
            chunk = records[i : i + rpc]
            calls.append(ApiCall(call_id=call_id, records=chunk))
            call_id += 1

        waves: list[Wave] = []
        wave_number = 0
        for i in range(0, len(calls), self.concurrency):
            wave_calls = calls[i : i + self.concurrency]
            waves.append(Wave(wave_number=wave_number, calls=wave_calls))
            wave_number += 1

        return waves

    async def execute_wave(
        self,
        wave: Wave,
        api_fn: Callable[[ApiCall], Awaitable[CallResult]],
    ) -> WaveResult:
        logger.info(
            f"Wave {wave.wave_number}: firing {wave.call_count} calls, "
            f"{wave.total_records} records"
        )
        start = time.monotonic()

        tasks = [api_fn(call) for call in wave.calls]
        call_results: list[CallResult] = await asyncio.gather(
            *tasks, return_exceptions=False
        )

        duration_ms = (time.monotonic() - start) * 1000
        wave_result = WaveResult(
            wave_number=wave.wave_number,
            call_results=call_results,
        )

        logger.info(
            f"Wave {wave.wave_number} complete in {duration_ms:.0f}ms: "
            f"success={wave_result.total_success}, failed={wave_result.total_failed}"
        )
        return wave_result

    async def execute_all_waves(
        self,
        records: list[SourceRecord],
        api_fn: Callable[[ApiCall], Awaitable[CallResult]],
    ) -> OperationResult:
        if not records:
            return OperationResult()

        result = OperationResult(total_source=len(records))
        waves = self.build_waves(records)

        logger.info(
            f"Executing {len(waves)} wave(s) for {len(records)} records "
            f"({self.concurrency} calls/wave × {self.resolvers_per_call} records/call)"
        )

        all_failures: list[RecordResult] = []

        for wave in waves:
            wave_result = await self.execute_wave(wave, api_fn)
            result.wave_results.append(wave_result)
            result.all_successes.extend(wave_result.successful_records)
            all_failures.extend(wave_result.failed_records)

        result.total_attempted = len(records)
        result.total_success = len(result.all_successes)

        if all_failures:
            logger.info(
                f"All waves complete. {len(all_failures)} failed records to retry."
            )
            retry_successes, final_failures = await self._retry_failed_records(
                all_failures, api_fn
            )
            result.total_retried = len(all_failures)
            result.all_successes.extend(retry_successes)
            result.total_success = len(result.all_successes)
            result.all_failures = final_failures
            result.total_failed = len(final_failures)
        else:
            result.all_failures = []
            result.total_failed = 0

        logger.info(
            f"Operation complete: attempted={result.total_attempted}, "
            f"success={result.total_success}, failed={result.total_failed}, "
            f"retried={result.total_retried}"
        )
        return result

    async def _retry_failed_records(
        self,
        failed_results: list[RecordResult],
        api_fn: Callable[[ApiCall], Awaitable[CallResult]],
    ) -> tuple[list[RecordResult], list[RecordResult]]:
        """Retry failed records with lower resolvers.

        Returns (all_retry_successes, final_failures) across all rounds.
        """
        all_retry_successes: list[RecordResult] = []
        current_failures = failed_results

        for retry_round in range(self.max_retry_rounds):
            if not current_failures:
                break

            records_to_retry = [fr.source_record for fr in current_failures]
            logger.info(
                f"Retry round {retry_round + 1}/{self.max_retry_rounds}: "
                f"{len(records_to_retry)} records with "
                f"{self.retry_resolvers_per_call} resolvers/call"
            )

            retry_waves = self.build_waves(
                records_to_retry, resolvers_per_call=self.retry_resolvers_per_call
            )

            round_successes: list[RecordResult] = []
            round_failures: list[RecordResult] = []
            for wave in retry_waves:
                wave_result = await self.execute_wave(wave, api_fn)
                round_successes.extend(wave_result.successful_records)
                round_failures.extend(wave_result.failed_records)

            all_retry_successes.extend(round_successes)

            if not round_failures:
                logger.info(
                    f"Retry round {retry_round + 1} resolved all failures"
                )
                current_failures = []
                break

            logger.warning(
                f"Retry round {retry_round + 1}: "
                f"{len(round_failures)} records still failing"
            )
            current_failures = round_failures

        return all_retry_successes, current_failures
