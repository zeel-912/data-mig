import sys
from pathlib import Path
from loguru import logger


LOG_FORMAT = (
    "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level:<7} | "
    "run={extra[run_id]} | op={extra[operation]} | "
    "{message}"
)

LOG_FORMAT_SIMPLE = (
    "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level:<7} | {message}"
)


def setup_logging(log_level: str = "INFO", log_dir: str = "./logs") -> None:
    logger.remove()

    logger.add(
        sys.stderr,
        format=LOG_FORMAT_SIMPLE,
        level=log_level,
        colorize=True,
    )

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    logger.add(
        str(log_path / "migration_{time:YYYY-MM-DD}.log"),
        format=LOG_FORMAT_SIMPLE,
        level="DEBUG",
        rotation="50 MB",
        retention=10,
        compression="gz",
    )


def get_logger(run_id: str = "-", operation: str = "-"):
    return logger.bind(run_id=run_id, operation=operation)
