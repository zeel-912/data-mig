class MigrationError(Exception):
    pass


class ConfigurationError(MigrationError):
    pass


class SystemLevelError(MigrationError):
    """Xray/Jira unavailable, auth failure, network outage, DB unavailable."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class RecordLevelError(MigrationError):
    """Individual record failure — carries source_id for tracking."""

    def __init__(
        self,
        message: str,
        source_id: str,
        error_code: str | None = None,
    ):
        super().__init__(message)
        self.source_id = source_id
        self.error_code = error_code


class RateLimitError(MigrationError):
    """429 received — carries retry_after_seconds from header."""

    def __init__(self, message: str, retry_after_seconds: float = 0):
        super().__init__(message)
        self.retry_after_seconds = retry_after_seconds


class GraphQLPartialError(MigrationError):
    """200 OK but some aliases in the batch failed.

    Carries separated successes and failures for per-record handling.
    """

    def __init__(
        self,
        message: str,
        successes: list[dict] | None = None,
        failures: list[dict] | None = None,
        raw_errors: list[dict] | None = None,
    ):
        super().__init__(message)
        self.successes = successes or []
        self.failures = failures or []
        self.raw_errors = raw_errors or []


class DependencyGateError(MigrationError):
    """Previous operation has unresolved failures — cannot proceed."""

    def __init__(self, message: str, blocking_operation: str):
        super().__init__(message)
        self.blocking_operation = blocking_operation
