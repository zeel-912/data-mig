import asyncio
import random
from functools import wraps
from typing import Callable, Awaitable, TypeVar
from loguru import logger

from common.exceptions import RateLimitError, SystemLevelError

T = TypeVar("T")


async def retry_with_backoff(
    fn: Callable[..., Awaitable[T]],
    *args,
    max_attempts: int = 4,
    base_delay: float = 2.0,
    max_delay: float = 60.0,
    retry_on: tuple[type[Exception], ...] = (RateLimitError, SystemLevelError),
    **kwargs,
) -> T:
    """Retry an async function with exponential backoff and jitter.

    Used for individual API calls that hit 429 or 5xx errors.
    Respects RateLimitError.retry_after_seconds when available.
    """
    last_exception = None

    for attempt in range(1, max_attempts + 1):
        try:
            return await fn(*args, **kwargs)
        except retry_on as e:
            last_exception = e

            if attempt == max_attempts:
                logger.error(
                    f"Retry exhausted after {max_attempts} attempts: {e}"
                )
                raise

            if isinstance(e, RateLimitError) and e.retry_after_seconds > 0:
                delay = e.retry_after_seconds
            else:
                delay = min(base_delay * (2 ** (attempt - 1)), max_delay)
                jitter = random.uniform(0.7, 1.3)
                delay *= jitter

            logger.warning(
                f"Attempt {attempt}/{max_attempts} failed: {e}. "
                f"Retrying in {delay:.1f}s"
            )
            await asyncio.sleep(delay)

    raise last_exception


def with_retry(
    max_attempts: int = 4,
    base_delay: float = 2.0,
    max_delay: float = 60.0,
    retry_on: tuple[type[Exception], ...] = (RateLimitError, SystemLevelError),
):
    """Decorator for async functions to add retry with exponential backoff."""

    def decorator(fn: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(fn)
        async def wrapper(*args, **kwargs) -> T:
            return await retry_with_backoff(
                fn,
                *args,
                max_attempts=max_attempts,
                base_delay=base_delay,
                max_delay=max_delay,
                retry_on=retry_on,
                **kwargs,
            )
        return wrapper
    return decorator


async def retry_rate_limited(
    fn: Callable[..., Awaitable[T]],
    *args,
    max_attempts: int = 4,
    **kwargs,
) -> T:
    """Retry specifically for rate-limited calls. Respects Retry-After header."""
    return await retry_with_backoff(
        fn,
        *args,
        max_attempts=max_attempts,
        base_delay=2.0,
        max_delay=120.0,
        retry_on=(RateLimitError,),
        **kwargs,
    )


async def retry_server_error(
    fn: Callable[..., Awaitable[T]],
    *args,
    max_attempts: int = 3,
    **kwargs,
) -> T:
    """Retry for 5xx server errors with shorter backoff."""
    return await retry_with_backoff(
        fn,
        *args,
        max_attempts=max_attempts,
        base_delay=1.0,
        max_delay=30.0,
        retry_on=(SystemLevelError,),
        **kwargs,
    )
