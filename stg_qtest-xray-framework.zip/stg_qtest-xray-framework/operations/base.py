import sqlite3
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
from loguru import logger

from config.operations import OperationName, ExecutionMode
from common.models import SourceRecord, OperationResult
from db.repositories.pipeline_repo import PipelineRepo
from db.repositories.operation_repo import OperationRepo
from db.repositories.batch_repo import BatchRepo
from db.repositories.mapping_repo import MappingRepo
from db.repositories.failed_record_repo import FailedRecordRepo
from db.repositories.reconciliation_repo import ReconciliationRepo


@dataclass
class PipelineContext:
    pipeline_run_id: int
    application_name: str
    root_input_module_id: int
    target_project_key: str
    target_project_id: str | None = None
    source_project_id: int | None = None
    migration_scope: str = "MIGRATION"
    mode: ExecutionMode = ExecutionMode.FULL
    source_ids: list[str] | None = None
    dry_run: bool = False


class BaseOperation(ABC):
    """Abstract base class for all migration operations.

    Each operation follows the lifecycle:
        extract -> transform -> load -> reconcile

    Subclasses implement the abstract methods for their specific entity.
    """

    operation_name: OperationName = None

    def __init__(
        self,
        conn: sqlite3.Connection,
        context: PipelineContext,
        xray_client=None,
        jira_client=None,
        settings=None,
    ):
        self.conn = conn
        self.context = context
        self.xray_client = xray_client
        self.jira_client = jira_client
        self.settings = settings

        self.pipeline_repo = PipelineRepo(conn)
        self.operation_repo = OperationRepo(conn)
        self.batch_repo = BatchRepo(conn)
        self.mapping_repo = MappingRepo(conn)
        self.failed_record_repo = FailedRecordRepo(conn)
        self.reconciliation_repo = ReconciliationRepo(conn)

        self.operation_run_id: int | None = None

    @abstractmethod
    def extract(self) -> list[SourceRecord]:
        """Read eligible source records from staging DB."""

    @abstractmethod
    def transform(self, records: list[SourceRecord]) -> list[dict]:
        """Transform source records into API payloads."""

    @abstractmethod
    async def load(self, records: list[SourceRecord]) -> OperationResult:
        """Send payloads to Xray/Jira and collect results."""

    def get_source_count(self) -> int:
        """Get total source record count for this operation (before filtering)."""
        return 0

    async def run(self) -> OperationResult:
        """Full operation lifecycle: extract -> transform -> load -> reconcile."""
        op_name = self.operation_name.value
        logger.info(f"[{op_name}] Starting operation")

        self.operation_run_id = self.operation_repo.create_operation_run(
            pipeline_run_id=self.context.pipeline_run_id,
            operation_name=op_name,
            operation_sequence=self._get_sequence(),
            operation_mode=self.context.mode.value,
        )

        try:
            records = self.extract()
            source_count = self.get_source_count() or len(records)
            logger.info(f"[{op_name}] Extracted {len(records)} eligible records (source total: {source_count})")

            if not records:
                logger.info(f"[{op_name}] No records to process")
                self.operation_repo.update_counts(
                    self.operation_run_id, source_count=source_count
                )
                self.operation_repo.update_status(self.operation_run_id, "COMPLETED")
                return OperationResult(total_source=source_count)

            if self.context.dry_run:
                logger.info(f"[{op_name}] DRY RUN - skipping load for {len(records)} records")
                self.operation_repo.update_status(self.operation_run_id, "COMPLETED")
                return OperationResult(total_source=source_count)

            result = await self.load(records)

            self._save_successes(result)
            self._save_failures(result)

            self.operation_repo.update_counts(
                self.operation_run_id,
                source_count=source_count,
                eligible_count=len(records),
                attempted_count=result.total_attempted,
                success_count=result.total_success,
                failure_count=result.total_failed,
                retry_count=result.total_retried,
            )

            recon_status = self._reconcile(source_count, result)

            if result.gate_passed:
                self.operation_repo.update_status(self.operation_run_id, "COMPLETED")
                self.operation_repo.update_gate_status(self.operation_run_id, "PASSED")
            else:
                self.operation_repo.update_status(self.operation_run_id, "GATE_BLOCKED")
                self.operation_repo.update_gate_status(self.operation_run_id, "BLOCKED")

            logger.info(
                f"[{op_name}] Complete: success={result.total_success}, "
                f"failed={result.total_failed}, gate={'PASSED' if result.gate_passed else 'BLOCKED'}"
            )
            return result

        except Exception as e:
            logger.error(f"[{op_name}] Operation failed with error: {e}")
            self.operation_repo.update_status(self.operation_run_id, "FAILED")
            raise

    def _get_sequence(self) -> int:
        from config.operations import OPERATION_SEQUENCE
        try:
            return OPERATION_SEQUENCE.index(self.operation_name) + 1
        except ValueError:
            return 0

    def _save_successes(self, result: OperationResult) -> None:
        if not result.all_successes:
            return

        mappings = []
        for sr in result.all_successes:
            mappings.append({
                "pipeline_run_id": self.context.pipeline_run_id,
                "operation_run_id": self.operation_run_id,
                "source_entity_type": sr.source_record.source_entity_type,
                "source_id": sr.source_record.source_id,
                "target_entity_type": self._get_target_entity_type(),
                "target_id": sr.target_id,
                "target_key": sr.target_key,
                "target_path": sr.target_path,
            })
        self.mapping_repo.save_mappings_bulk(mappings)

    def _save_failures(self, result: OperationResult) -> None:
        if not result.all_failures:
            return

        records = []
        for fr in result.all_failures:
            records.append({
                "pipeline_run_id": self.context.pipeline_run_id,
                "operation_run_id": self.operation_run_id,
                "operation_name": self.operation_name.value,
                "source_entity_type": fr.source_record.source_entity_type,
                "primary_source_id": fr.source_record.source_id,
                "error_code": fr.error_code,
                "error_message": fr.error_message,
            })
        self.failed_record_repo.save_failed_records_bulk(records)

    def _reconcile(self, source_count: int, result: OperationResult) -> str:
        mapped_count = self.mapping_repo.get_mapped_count_for_operation(self.operation_run_id)
        unresolved_count = self.failed_record_repo.get_unresolved_count(self.operation_run_id)

        status = "CLEAN" if unresolved_count == 0 else "UNRESOLVED_FAILURES"

        self.reconciliation_repo.save_reconciliation(
            pipeline_run_id=self.context.pipeline_run_id,
            operation_run_id=self.operation_run_id,
            operation_name=self.operation_name.value,
            source_count=source_count,
            eligible_count=result.total_attempted,
            attempted_count=result.total_attempted,
            success_count=result.total_success,
            failure_count=result.total_failed,
            mapped_count=mapped_count,
            unresolved_count=unresolved_count,
            status=status,
        )

        logger.info(
            f"[{self.operation_name.value}] Reconciliation: "
            f"source={source_count}, mapped={mapped_count}, "
            f"unresolved={unresolved_count}, status={status}"
        )
        return status

    def _get_target_entity_type(self) -> str:
        """Override in subclass to specify target entity type for id_mapping."""
        return "UNKNOWN"
