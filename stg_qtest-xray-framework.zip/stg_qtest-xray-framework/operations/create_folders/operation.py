from loguru import logger

from config.operations import OperationName
from operations.base import BaseOperation
from operations.registry import register_operation
from operations.create_folders.queries import get_modules_for_root, get_module_count
from operations.create_folders.transformer import build_folder_paths
from common.models import SourceRecord, OperationResult, RecordResult
from common.retry import retry_with_backoff
from common.exceptions import RateLimitError, SystemLevelError


@register_operation(OperationName.CREATE_FOLDERS)
class CreateFoldersOperation(BaseOperation):
    """Create Xray Test Repository folders from qTest modules.

    SEQUENTIAL execution — parent folders must exist before children.
    Uses single createFolder(projectId, path) calls in depth order.
    NOT wave-based.
    """

    def extract(self) -> list[SourceRecord]:
        modules = get_modules_for_root(self.conn, self.context.root_input_module_id)
        folder_data = build_folder_paths(modules)

        records = []
        for fd in folder_data:
            if self.mapping_repo.mapping_exists("MODULE", fd["module_id"]):
                continue
            records.append(SourceRecord(
                source_entity_type="MODULE",
                source_id=fd["module_id"],
                data=fd,
            ))

        return records

    def transform(self, records: list[SourceRecord]) -> list[dict]:
        return [
            {
                "projectId": self.context.target_project_key,
                "path": r.data["path"],
            }
            for r in records
        ]

    async def load(self, records: list[SourceRecord]) -> OperationResult:
        """Create folders SEQUENTIALLY (parent before child)."""
        result = OperationResult(total_source=len(records), total_attempted=len(records))

        for i, record in enumerate(records):
            path = record.data["path"]
            logger.info(
                f"[CREATE_FOLDERS] ({i+1}/{len(records)}) Creating: {path}"
            )

            try:
                record_result = await self._create_single_folder(record)
                if record_result.success:
                    result.all_successes.append(record_result)
                else:
                    result.all_failures.append(record_result)
            except Exception as e:
                logger.error(f"[CREATE_FOLDERS] Failed to create {path}: {e}")
                result.all_failures.append(RecordResult(
                    source_record=record,
                    success=False,
                    error_code="SYSTEM_ERROR",
                    error_message=str(e),
                ))

        result.total_success = len(result.all_successes)
        result.total_failed = len(result.all_failures)
        return result

    async def _create_single_folder(self, record: SourceRecord) -> RecordResult:
        """Create a single folder with retry on rate limit / server error."""
        path = record.data["path"]
        project_id = self.context.target_project_key

        query = self.xray_client.build_aliased_mutation(
            "createFolder",
            [{"projectId": project_id, "path": path}],
            alias_prefix="f",
            return_fields='{ folder { path name } }',
        )

        async def _do_create():
            return await self.xray_client.execute(query)

        try:
            response_data = await retry_with_backoff(
                _do_create, max_attempts=3, base_delay=2.0
            )
        except (RateLimitError, SystemLevelError) as e:
            return RecordResult(
                source_record=record,
                success=False,
                error_code=type(e).__name__,
                error_message=str(e),
            )

        data = response_data.get("data", {}) or {}
        errors = response_data.get("errors", []) or []

        alias_data = data.get("f_0")

        if errors:
            error_msg = errors[0].get("message", "Unknown error")
            if "already exists" in error_msg.lower() or "duplicate" in error_msg.lower():
                logger.info(f"[CREATE_FOLDERS] Folder already exists: {path} (skipping)")
                return RecordResult(
                    source_record=record,
                    success=True,
                    target_path=path,
                )
            return RecordResult(
                source_record=record,
                success=False,
                error_code="GRAPHQL_ERROR",
                error_message=error_msg,
            )

        if alias_data is None:
            return RecordResult(
                source_record=record,
                success=False,
                error_code="NULL_RESPONSE",
                error_message="createFolder returned null",
            )

        folder_info = alias_data.get("folder", {})
        created_path = folder_info.get("path", path)

        return RecordResult(
            source_record=record,
            success=True,
            target_path=created_path,
            raw_response=alias_data,
        )

    def get_source_count(self) -> int:
        return get_module_count(self.conn, self.context.root_input_module_id)

    def _get_target_entity_type(self) -> str:
        return "XRAY_FOLDER"
