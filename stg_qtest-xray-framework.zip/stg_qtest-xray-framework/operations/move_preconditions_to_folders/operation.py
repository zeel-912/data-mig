from functools import partial
from loguru import logger

from config.operations import OperationName
from operations.base import BaseOperation
from operations.registry import register_operation
from operations.move_preconditions_to_folders.queries import (
    get_unmoved_preconditions,
    get_folder_mapping,
)
from operations.move_preconditions_to_folders.transformer import build_move_to_folder_payload
from operations.create_folders.transformer import normalize_path
from common.models import SourceRecord, OperationResult, ApiCall, CallResult
from common.batch_executor import WaveExecutor


@register_operation(OperationName.MOVE_PRECONDITIONS_TO_FOLDERS)
class MovePreconditionsToFoldersOperation(BaseOperation):
    """Move created Xray Preconditions into their target folders.

    Joins id_mapping (precondition issueIds) with module data to resolve folder paths,
    then calls addTestsToFolder(folderId, testIssueIds) via wave-based execution.
    """

    MUTATION_TEMPLATE = "addTestsToFolder"
    RETURN_FIELDS = "{ addedTests warning }"

    def extract(self) -> list[SourceRecord]:
        rows = get_unmoved_preconditions(self.conn, self.context.root_input_module_id)
        folder_map = get_folder_mapping(self.conn, self.context.application_name)

        records = []
        skipped_no_folder = 0

        for row in rows:
            module_path = row["module_path"]
            if not module_path:
                skipped_no_folder += 1
                continue

            normalized = normalize_path(module_path)
            folder_id = folder_map.get(normalized)

            if not folder_id:
                skipped_no_folder += 1
                continue

            records.append(SourceRecord(
                source_entity_type="PRECONDITION_FOLDER_MOVE",
                source_id=str(row["test_case_version_id"]),
                data={
                    "test_case_version_id": row["test_case_version_id"],
                    "xray_issue_id": row["xray_issue_id"],
                    "xray_issue_key": row["xray_issue_key"],
                    "folder_id": folder_id,
                    "folder_path": normalized,
                },
            ))

        if skipped_no_folder:
            logger.warning(
                f"[MOVE_PRECONDITIONS_TO_FOLDERS] Skipped {skipped_no_folder} "
                f"preconditions with no matching folder"
            )

        return records

    def transform(self, records: list[SourceRecord]) -> list[dict]:
        return [build_move_to_folder_payload(r) for r in records]

    async def load(self, records: list[SourceRecord]) -> OperationResult:
        """Move preconditions to folders via wave-based execution."""
        wave_executor = WaveExecutor(
            concurrency=self.settings.wave.concurrency,
            resolvers_per_call=self.settings.wave.resolvers_per_call,
            retry_resolvers_per_call=self.settings.wave.retry_resolvers_per_call,
            max_retry_rounds=self.settings.wave.max_retries_per_wave,
        )

        api_fn = partial(self._execute_call)
        return await wave_executor.execute_all_waves(records, api_fn)

    async def _execute_call(self, call: ApiCall) -> CallResult:
        """Execute a single batched GraphQL call for folder moves."""
        return await self.xray_client.execute_api_call(
            call=call,
            mutation_template=self.MUTATION_TEMPLATE,
            record_to_args_fn=self._record_to_args,
            alias_prefix="mf",
            return_fields=self.RETURN_FIELDS,
            target_id_field="addedTests",
        )

    def _record_to_args(self, record: SourceRecord) -> dict:
        return build_move_to_folder_payload(record)

    def get_source_count(self) -> int:
        rows = get_unmoved_preconditions(self.conn, self.context.root_input_module_id)
        return len(rows)

    def _get_target_entity_type(self) -> str:
        return "XRAY_FOLDER_MOVE"
