from functools import partial
from loguru import logger

from config.operations import OperationName
from operations.base import BaseOperation
from operations.registry import register_operation
from operations.link_preconditions_to_tests.queries import get_unlinked_preconditions
from operations.link_preconditions_to_tests.transformer import build_link_precondition_payload
from common.models import SourceRecord, OperationResult, ApiCall, CallResult
from common.batch_executor import WaveExecutor


@register_operation(OperationName.LINK_PRECONDITIONS_TO_TESTS)
class LinkPreconditionsToTestsOperation(BaseOperation):
    """Link Xray Precondition issues to their parent Test issues.

    Uses addPreconditionsToTest(issueId, preconditionIssueIds) mutation.
    Joins precondition id_mapping with test_case_versions to find the parent test_case_id,
    then looks up the test case's Xray issueId from id_mapping.
    Wave-based execution.
    """

    MUTATION_TEMPLATE = "addPreconditionsToTest"
    RETURN_FIELDS = "{ addedPreconditions warning }"

    def extract(self) -> list[SourceRecord]:
        rows = get_unlinked_preconditions(self.conn, self.context.root_input_module_id)

        records = []
        for row in rows:
            records.append(SourceRecord(
                source_entity_type="PRECONDITION_LINK",
                source_id=str(row["precondition_version_id"]),
                data={
                    "precondition_version_id": row["precondition_version_id"],
                    "precondition_issue_id": row["precondition_issue_id"],
                    "precondition_issue_key": row["precondition_issue_key"],
                    "test_case_id": row["test_case_id"],
                    "test_issue_id": row["test_issue_id"],
                    "test_issue_key": row["test_issue_key"],
                },
            ))

        return records

    def transform(self, records: list[SourceRecord]) -> list[dict]:
        return [build_link_precondition_payload(r) for r in records]

    async def load(self, records: list[SourceRecord]) -> OperationResult:
        """Link preconditions to tests via wave-based execution."""
        wave_executor = WaveExecutor(
            concurrency=self.settings.wave.concurrency,
            resolvers_per_call=self.settings.wave.resolvers_per_call,
            retry_resolvers_per_call=self.settings.wave.retry_resolvers_per_call,
            max_retry_rounds=self.settings.wave.max_retries_per_wave,
        )

        api_fn = partial(self._execute_call)
        return await wave_executor.execute_all_waves(records, api_fn)

    async def _execute_call(self, call: ApiCall) -> CallResult:
        return await self.xray_client.execute_api_call(
            call=call,
            mutation_template=self.MUTATION_TEMPLATE,
            record_to_args_fn=self._record_to_args,
            alias_prefix="lp",
            return_fields=self.RETURN_FIELDS,
            target_id_field="addedPreconditions",
        )

    def _record_to_args(self, record: SourceRecord) -> dict:
        return build_link_precondition_payload(record)

    def get_source_count(self) -> int:
        rows = get_unlinked_preconditions(self.conn, self.context.root_input_module_id)
        return len(rows)

    def _get_target_entity_type(self) -> str:
        return "XRAY_PRECONDITION_LINK"
