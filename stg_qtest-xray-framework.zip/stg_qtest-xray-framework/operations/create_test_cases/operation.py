from collections import defaultdict
from functools import partial
from loguru import logger

from config.operations import OperationName
from operations.base import BaseOperation
from operations.registry import register_operation
from operations.create_test_cases.queries import (
    get_test_cases_for_project,
    get_test_steps_for_versions,
    get_test_case_count,
)
from operations.create_test_cases.transformer import build_test_case_payload
from common.models import SourceRecord, OperationResult, ApiCall, CallResult
from common.batch_executor import WaveExecutor


@register_operation(OperationName.CREATE_TEST_CASES)
class CreateTestCasesOperation(BaseOperation):
    """Create Xray Manual test issues from qTest test cases (latest version only).

    Includes test steps from stg_qtest_test_steps.
    Wave-based execution: 40 calls x 12 resolvers = 480 records/wave.
    NO folder mapping — folder assignment is a separate operation.
    """

    MUTATION_TEMPLATE = "createTest"
    RETURN_FIELDS = '{ issueId jira(fields: ["key"]) { key } }'

    def extract(self) -> list[SourceRecord]:
        rows = get_test_cases_for_project(self.conn, self.context.root_input_module_id)

        version_ids = [row["test_case_version_id"] for row in rows]
        steps_rows = get_test_steps_for_versions(
            self.conn, self.context.root_input_module_id, version_ids
        )

        steps_by_version = defaultdict(list)
        for step in steps_rows:
            steps_by_version[step["test_case_version_id"]].append({
                "step_order": step["step_order"],
                "step_description": step["step_description"],
                "expected_result": step["expected_result"],
            })

        records = []
        for row in rows:
            tc_id = str(row["test_case_id"])
            if self.mapping_repo.mapping_exists("TEST_CASE", tc_id):
                continue

            version_id = row["test_case_version_id"]
            steps = steps_by_version.get(version_id, [])

            records.append(SourceRecord(
                source_entity_type="TEST_CASE",
                source_id=tc_id,
                data={
                    "test_case_id": row["test_case_id"],
                    "test_case_name": row["test_case_name"],
                    "test_case_version_id": version_id,
                    "version": row["version"],
                    "description": row["description"],
                    "priority_name": row["priority_name"],
                    "module_path": row["module_path"],
                    "input_module_id": row["input_module_id"],
                    "steps": steps,
                },
            ))

        return records

    def transform(self, records: list[SourceRecord]) -> list[dict]:
        return [
            build_test_case_payload(r.data, r.data.get("steps", []))
            for r in records
        ]

    async def load(self, records: list[SourceRecord]) -> OperationResult:
        """Create test cases via wave-based execution."""
        wave_executor = WaveExecutor(
            concurrency=self.settings.wave.concurrency,
            resolvers_per_call=self.settings.wave.resolvers_per_call,
            retry_resolvers_per_call=self.settings.wave.retry_resolvers_per_call,
            max_retry_rounds=self.settings.wave.max_retries_per_wave,
        )

        api_fn = partial(self._execute_call)
        return await wave_executor.execute_all_waves(records, api_fn)

    async def _execute_call(self, call: ApiCall) -> CallResult:
        """Execute a single batched GraphQL call for test cases."""
        return await self.xray_client.execute_api_call(
            call=call,
            mutation_template=self.MUTATION_TEMPLATE,
            record_to_args_fn=self._record_to_args,
            alias_prefix="tc",
            return_fields=self.RETURN_FIELDS,
            target_id_field="issueId",
            target_key_field="key",
        )

    def _record_to_args(self, record: SourceRecord) -> dict:
        """Convert a SourceRecord to GraphQL mutation arguments."""
        return build_test_case_payload(record.data, record.data.get("steps", []))

    def get_source_count(self) -> int:
        return get_test_case_count(self.conn, self.context.root_input_module_id)

    def _get_target_entity_type(self) -> str:
        return "XRAY_TEST"
