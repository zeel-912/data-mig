from enum import Enum
from dataclasses import dataclass


class OperationName(str, Enum):
    VALIDATE_SCOPE = "VALIDATE_SCOPE"
    CREATE_FOLDERS = "CREATE_FOLDERS"
    CREATE_PRECONDITIONS = "CREATE_PRECONDITIONS"
    CREATE_TEST_CASES = "CREATE_TEST_CASES"
    MOVE_PRECONDITIONS_TO_FOLDERS = "MOVE_PRECONDITIONS_TO_FOLDERS"
    MOVE_TESTS_TO_FOLDERS = "MOVE_TESTS_TO_FOLDERS"
    LINK_PRECONDITIONS_TO_TESTS = "LINK_PRECONDITIONS_TO_TESTS"
    CREATE_TEST_EXECUTIONS = "CREATE_TEST_EXECUTIONS"
    ADD_TESTS_TO_EXECUTIONS = "ADD_TESTS_TO_EXECUTIONS"
    FETCH_RUN_IDS = "FETCH_RUN_IDS"
    UPDATE_RUN_RESULTS = "UPDATE_RUN_RESULTS"
    UPDATE_RUN_METADATA = "UPDATE_RUN_METADATA"
    FETCH_STEP_IDS = "FETCH_STEP_IDS"
    UPDATE_STEP_RESULTS = "UPDATE_STEP_RESULTS"
    CREATE_LINK_DEFECTS = "CREATE_LINK_DEFECTS"
    ATTACHMENTS = "ATTACHMENTS"
    COMMENTS = "COMMENTS"
    WORKFLOW_TRANSITIONS = "WORKFLOW_TRANSITIONS"
    FINAL_RECONCILIATION = "FINAL_RECONCILIATION"


OPERATION_SEQUENCE: list[OperationName] = [
    OperationName.VALIDATE_SCOPE,
    OperationName.CREATE_FOLDERS,
    OperationName.CREATE_PRECONDITIONS,
    OperationName.CREATE_TEST_CASES,
    OperationName.MOVE_PRECONDITIONS_TO_FOLDERS,
    OperationName.MOVE_TESTS_TO_FOLDERS,
    OperationName.LINK_PRECONDITIONS_TO_TESTS,
    OperationName.CREATE_TEST_EXECUTIONS,
    OperationName.ADD_TESTS_TO_EXECUTIONS,
    OperationName.FETCH_RUN_IDS,
    OperationName.UPDATE_RUN_RESULTS,
    OperationName.UPDATE_RUN_METADATA,
    OperationName.FETCH_STEP_IDS,
    OperationName.UPDATE_STEP_RESULTS,
    OperationName.CREATE_LINK_DEFECTS,
    OperationName.ATTACHMENTS,
    OperationName.COMMENTS,
    OperationName.WORKFLOW_TRANSITIONS,
    OperationName.FINAL_RECONCILIATION,
]


class ApiAdapter(str, Enum):
    XRAY_GRAPHQL = "XRAY_GRAPHQL"
    JIRA_REST = "JIRA_REST"


@dataclass
class OperationConfig:
    api_adapter: ApiAdapter
    sequential: bool = False
    resolvers_per_call_override: int | None = None


OPERATION_CONFIGS: dict[OperationName, OperationConfig] = {
    OperationName.VALIDATE_SCOPE: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
        sequential=True,
    ),
    OperationName.CREATE_FOLDERS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
        sequential=True,
    ),
    OperationName.CREATE_PRECONDITIONS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.CREATE_TEST_CASES: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.MOVE_PRECONDITIONS_TO_FOLDERS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.MOVE_TESTS_TO_FOLDERS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.LINK_PRECONDITIONS_TO_TESTS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.CREATE_TEST_EXECUTIONS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.ADD_TESTS_TO_EXECUTIONS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.FETCH_RUN_IDS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.UPDATE_RUN_RESULTS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.UPDATE_RUN_METADATA: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.FETCH_STEP_IDS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.UPDATE_STEP_RESULTS: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
    ),
    OperationName.CREATE_LINK_DEFECTS: OperationConfig(
        api_adapter=ApiAdapter.JIRA_REST,
    ),
    OperationName.ATTACHMENTS: OperationConfig(
        api_adapter=ApiAdapter.JIRA_REST,
    ),
    OperationName.COMMENTS: OperationConfig(
        api_adapter=ApiAdapter.JIRA_REST,
    ),
    OperationName.WORKFLOW_TRANSITIONS: OperationConfig(
        api_adapter=ApiAdapter.JIRA_REST,
    ),
    OperationName.FINAL_RECONCILIATION: OperationConfig(
        api_adapter=ApiAdapter.XRAY_GRAPHQL,
        sequential=True,
    ),
}


class PipelineName(str, Enum):
    STG_TO_XRAY = "STG_TO_XRAY"


class ExecutionMode(str, Enum):
    FULL = "FULL"
    OPERATION_ONLY = "OPERATION_ONLY"
    SPECIFIC_IDS = "SPECIFIC_IDS"
    FAILED_RECORDS = "FAILED_RECORDS"
